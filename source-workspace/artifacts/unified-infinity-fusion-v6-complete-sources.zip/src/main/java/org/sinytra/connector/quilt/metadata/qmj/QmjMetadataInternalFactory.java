/*
 * Adapted for the native-quilt-v1 host compatibility profile (2026).
 * Loader-engine references are replaced by isolated host-backed/value implementations.
 * Copyright 2024 QuiltMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.sinytra.connector.quilt.metadata.qmj;

import java.util.ArrayList;
import java.util.Collection;

import org.quiltmc.loader.api.ModDependency;
import org.quiltmc.loader.api.ModDependency.Only;
import org.quiltmc.loader.api.ModDependencyIdentifier;
import org.quiltmc.loader.api.VersionRange;

/** Various internal metadata factories - don't use these, instead use the actual public factory methods in
 * {@link ModDependency} */
public class QmjMetadataInternalFactory {

	public static ModDependency.Only createDepOnly(ModDependencyIdentifier id, VersionRange versionRange, String reason,
		ModDependency unless, boolean optional) {

		return new ModDependencyImpl.OnlyImpl("<created-via-api>", id, versionRange, reason, optional, unless);
	}

	public static ModDependency.Any createDepAny(Collection<Only> deps) {
		return new ModDependencyImpl.AnyImpl("<created-via-api>", new ArrayList<>(deps));
	}

	public static ModDependency.All createDepAll(Collection<Only> deps) {
		return new ModDependencyImpl.AllImpl("<created-via-api>", new ArrayList<>(deps));
	}
}
