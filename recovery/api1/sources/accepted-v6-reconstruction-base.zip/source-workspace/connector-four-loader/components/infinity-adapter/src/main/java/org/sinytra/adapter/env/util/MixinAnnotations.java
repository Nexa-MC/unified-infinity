package org.sinytra.adapter.env.util;

public class MixinAnnotations {
    // Standard mixins
    public static final String INJECT = "Lorg/spongepowered/asm/mixin/injection/Inject;";
    public static final String REDIRECT = "Lorg/spongepowered/asm/mixin/injection/Redirect;";
    public static final String MODIFY_ARG = "Lorg/spongepowered/asm/mixin/injection/ModifyArg;";
    public static final String MODIFY_ARGS = "Lorg/spongepowered/asm/mixin/injection/ModifyArgs;";
    public static final String MODIFY_VAR = "Lorg/spongepowered/asm/mixin/injection/ModifyVariable;";
    public static final String MODIFY_CONST = "Lorg/spongepowered/asm/mixin/injection/ModifyConstant;";
    public static final String OVERWRITE = "Lorg/spongepowered/asm/mixin/Overwrite;";
    // Interface mixins
    public static final String ACCESSOR = "Lorg/spongepowered/asm/mixin/gen/Accessor;";
    public static final String INVOKER = "Lorg/spongepowered/asm/mixin/gen/Invoker;";
    // Mixinextras annotations
    public static final String MODIFY_EXPR_VAL = "Lcom/llamalad7/mixinextras/injector/ModifyExpressionValue;";
    public static final String MODIFY_EXPR_VAL_INTERNAL_NAME = "com/llamalad7/mixinextras/injector/ModifyExpressionValue";
    public static final String MODIFY_RETURN_VAL = "Lcom/llamalad7/mixinextras/injector/ModifyReturnValue;";
    public static final String MODIFY_RETURN_VAL_INTERNAL_NAME = "com/llamalad7/mixinextras/injector/ModifyReturnValue";
    public static final String WRAP_OPERATION = "Lcom/llamalad7/mixinextras/injector/wrapoperation/WrapOperation;";
    public static final String WRAP_OPERATION_INTERNAL_NAME = "com/llamalad7/mixinextras/injector/wrapoperation/WrapOperation";
    public static final String WRAP_WITH_CONDITION = "Lcom/llamalad7/mixinextras/injector/WrapWithCondition;";
    public static final String LOCAL = "Lcom/llamalad7/mixinextras/sugar/Local;";
    public static final String SHARE = "Lcom/llamalad7/mixinextras/sugar/Share;";
    // Adapter custom mixin injectors
    public static final String MODIFY_INSTANCEOF_VAL = "Lorg/sinytra/adapter/runtime/inject/ModifyInstanceofValue;";
    // Misc
    public static final String MIXIN = "Lorg/spongepowered/asm/mixin/Mixin;";
    public static final String AT = "Lorg/spongepowered/asm/mixin/injection/At;";
    public static final String UNIQUE = "Lorg/spongepowered/asm/mixin/Unique;";
    public static final String SHADOW = "Lorg/spongepowered/asm/mixin/Shadow;";
    public static final String COERCE = "Lorg/spongepowered/asm/mixin/injection/Coerce;";
    public static final String CONSTANT = "Lorg/spongepowered/asm/mixin/injection/Constant;";
    public static final String SLICE = "Lorg/spongepowered/asm/mixin/injection/Slice;";
}
