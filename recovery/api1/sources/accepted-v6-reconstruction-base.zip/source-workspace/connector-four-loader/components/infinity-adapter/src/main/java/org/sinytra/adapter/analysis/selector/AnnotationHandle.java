package org.sinytra.adapter.analysis.selector;

import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.tree.AnnotationNode;

import java.util.*;

public final class AnnotationHandle {
    private final AnnotationNode annotationNode;
    private final Map<String, AnnotationValueHandle<?>> handleCache = new HashMap<>();

    public AnnotationHandle(AnnotationNode annotationNode) {
        this.annotationNode = Objects.requireNonNull(annotationNode);
    }

    public String getDesc() {
        return this.annotationNode.desc;
    }

    @Deprecated
    public boolean matchesDesc(String desc) {
        return this.annotationNode.desc.equals(desc);
    }

    public AnnotationNode unwrap() {
        return this.annotationNode;
    }

    public AnnotationHandle copy() {
        AnnotationNode copy = new AnnotationNode(this.annotationNode.desc);
        this.annotationNode.accept(copy);
        return new AnnotationHandle(copy);
    }

    public AnnotationHandle getNestedOrAppend(String key, String desc) {
        AnnotationHandle existing = getNested(key).orElse(null);
        if (existing != null) {
            return existing;
        }
        AnnotationNode node = new AnnotationNode(desc);
        appendValue(key, node);
        return getNested(key).orElseThrow();
    }

    public Optional<AnnotationHandle> getNested(String key) {
        return getValue(key)
            .<AnnotationNode>flatMap(AnnotationValueHandle::maybeUnwrap)
            .map(AnnotationHandle::new);
    }

    @SuppressWarnings("unchecked")
    public <T> Optional<AnnotationValueHandle<T>> getValue(String key) {
        AnnotationValueHandle<T> handle = (AnnotationValueHandle<T>) this.handleCache.computeIfAbsent(key, k -> AnnotationValueHandle.create(this.annotationNode, key).orElse(null));
        return Optional.ofNullable(handle);
    }

    public void removeValues(String... keys) {
        if (this.annotationNode.values != null) {
            Collection<String> toRemove = Set.of(keys);
            for (int keyIdx = 0; keyIdx < this.annotationNode.values.size(); keyIdx += 2) {
                String atKey = (String) this.annotationNode.values.get(keyIdx);
                if (toRemove.contains(atKey)) {
                    int valueIdx = keyIdx + 1;
                    this.annotationNode.values.remove(valueIdx);
                    this.annotationNode.values.remove(keyIdx);
                    keyIdx -= 2;
                }
            }
            this.handleCache.clear();
        }
    }

    public void appendValue(String key, Object value) {
        if (this.annotationNode.values == null) {
            this.annotationNode.values = new ArrayList<>();
        }
        this.annotationNode.values.add(key);
        this.annotationNode.values.add(value);
        this.handleCache.remove(key);
    }

    public void setOrAppendNonNull(String key, @Nullable Object value) {
        if (value == null) {
            removeValues(key);
        } else {
            getValue(key).ifPresentOrElse(
                v -> v.set(value),
                () -> appendValue(key, value)
            );
        }
    }
}
