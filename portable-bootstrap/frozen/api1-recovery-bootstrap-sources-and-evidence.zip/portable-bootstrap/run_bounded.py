#!/usr/bin/env python3
"""One bounded official installer or source-build invocation; no game task."""
import argparse,datetime,json,os,pathlib,subprocess,time,urllib.parse
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent/'work/api1'
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['gradle-core','gradle-product','installer-client','installer-neo-server','installer-forge-server']);p.add_argument('args',nargs=argparse.REMAINDER);a=p.parse_args()
    env=os.environ.copy();jdk=ROOT/'.toolchains/jdk-21.0.12.1+1';env['JAVA_HOME']=str(jdk);env['PATH']=str(jdk/'bin')+':'+env['PATH'];env['CI']='true';env['PUBLISH_RELEASE_TYPE']='alpha';env['GRADLE_USER_HOME']=str(ROOT/'source-workspace/gradle-cache')
    env['XDG_CACHE_HOME']=str(ROOT/'source-workspace/xdg-cache');env['XDG_CONFIG_HOME']=str(ROOT/'source-workspace/xdg-config')
    options=['-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts','-Duser.home='+str(ROOT/'source-workspace/home')]
    proxy=urllib.parse.urlparse(env.get('HTTPS_PROXY') or env.get('HTTP_PROXY',''))
    if proxy.hostname:
        for scheme in ['http','https']:options.extend([f'-D{scheme}.proxyHost={proxy.hostname}',f'-D{scheme}.proxyPort={proxy.port}'])
    env['JAVA_TOOL_OPTIONS']=' '.join(options);env['GRADLE_OPTS']=' '.join(options);env['_JAVA_OPTIONS']='-Xmx512m -XX:ActiveProcessorCount=1'
    for key in ['GITHUB_OUTPUT','GITHUB_TOKEN','MAVEN_USERNAME','MAVEN_PASSWORD']:env.pop(key,None)
    env['FORGE_FACADE_HOST_LIBRARIES']=str(ROOT/'run/neoforge-native/libraries')
    if a.mode.startswith('gradle'):
        if not a.args or any(x.lower().split(':')[-1].startswith(('run','publish','upload','release','decompile')) for x in a.args):raise ValueError('Only explicit build/check/preparation tasks')
        project=ROOT/('source-workspace/connector-four-loader' if a.mode=='gradle-core' else 'runtime-bundle')
        cmd=[str(ROOT/'.toolchains/gradle-8.11.1/bin/gradle'),'--no-daemon','--console=plain','--max-workers=1','--no-parallel','--dependency-verification=strict','-Dorg.gradle.jvmargs=-Xmx512m -XX:ActiveProcessorCount=1','--project-cache-dir',str(HERE/(a.mode+'-project-cache')),'--init-script',str(HERE/'bounded-build.init.gradle'),'-p',str(project),*a.args]
        cwd=ROOT
    else:
        targets={'installer-client':('docs/research/upstream/neoforge-21.1.219-installer.jar','run/client-dev','--installClient'),'installer-neo-server':('docs/research/upstream/neoforge-21.1.219-installer.jar','run/neoforge-native','--installServer'),'installer-forge-server':('docs/four-loader/forge/upstream/forge-1.21.1-52.1.0-installer.jar','run/forge-native-probe','--installServer')}
        jar,target,flag=targets[a.mode];profile=ROOT/target;profile.mkdir(parents=True,exist_ok=True)
        if flag=='--installClient':
            launcher=profile/'launcher_profiles.json'
            if not launcher.exists():launcher.write_text('{"profiles":{},"settings":{}}\n')
        cwd=profile/'installer-work';cwd.mkdir(exist_ok=True)
        cmd=[str(jdk/'bin/java'),'-Xmx512m','-XX:ActiveProcessorCount=1','-jar',str(ROOT/jar),flag,str(profile)]
    out=HERE/'evidence';out.mkdir(exist_ok=True);attempt=1
    while (out/f'{a.mode}-{attempt:03d}.json').exists() or (out/f'{a.mode}-{attempt:03d}.log').exists():attempt+=1
    stem=out/f'{a.mode}-{attempt:03d}';receipt={'mode':a.mode,'command':cmd,'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'perJvmHeapMiB':512,'activeProcessors':1,'gradleWorkers':1,'noGameTask':True,'status':'RUNNING'}
    stem.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
    with stem.with_suffix('.log').open('w') as log:
        result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    receipt.update(exitCode=result.returncode,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS' if result.returncode==0 else 'FAILED');stem.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'receipt':str(stem.with_suffix('.json')),'log':str(stem.with_suffix('.log'))}))
    raise SystemExit(result.returncode)
if __name__=='__main__':main()
