#!/usr/bin/env python3
"""Build/check PRODUCT against the already verified recovered API1 core tuple."""
import hashlib,json,pathlib,subprocess
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent/'work/api1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
artifacts=json.loads((HERE/'evidence/built-core-artifacts.json').read_text())
for row in artifacts.values():assert sha(pathlib.Path(row['path']))==row['sha256']
manifest=ROOT/'run/client-dev/development-build/moddev/client-launch-inputs.json'
for row in json.loads(manifest.read_text())['inputs']:assert sha(pathlib.Path(row['path']))==row['sha256']
args=['python',str(HERE/'run_bounded.py'),'gradle-product','--offline',
      '-PmanagedCoreJar='+artifacts['service']['path'],'-PmanagedCoreSha256='+artifacts['service']['sha256'],
      '-PunifiedFmlJar='+artifacts['fml']['path'],
      '-PffapiJar='+str(ROOT/'docs/research/upstream/ffapi-baseline.jar'),
      '-PqslInventory='+str(ROOT/'docs/four-loader/quilt/bundled-tooltip.json'),
      '-PclientClasspathManifest='+str(manifest),'jar','sourcesJar','check']
raise SystemExit(subprocess.call(args))
