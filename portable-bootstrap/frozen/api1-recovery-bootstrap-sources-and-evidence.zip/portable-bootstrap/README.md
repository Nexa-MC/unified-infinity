# API1 recovery and portable preparation

The October 5 fresh-workspace build succeeded locally. This directory contains
the bounded restoration/build helpers, exact download locks and receipts.
The working source root is `../work/api1`; durable original source packages live
separately under `../recovery/api1`. C1 was recovered independently and has not
been applied to this API1 tree.

Verified results:

- All 736 API1 snapshot files and 659 core identity records match the durable
  package. The regenerated identity is exactly
  `bfe476f62babed3299968ff1ce09f013dc9e91900541605d639c6a98e242c595`, including
  all 169 external dependency hashes
- All 116 FML compile inputs were restored. The official NeoForge 21.1.219
  installer regenerated all four previously missing client artifacts with their
  exact original SHA-256 values at 512 MiB
- Fresh `fullJar`, source JARs and full aggregate `check` passed. Matched PRODUCT
  build/check passed. The clean Mojmap probe compile input and both project-owned
  Forge probe JARs reproduce their original bytes
- FML reproduces the entire frozen API1 JAR byte-for-byte. The 19 PRODUCT class
  entries and all 37 PRODUCT source/build files also match their frozen records
- SERVICE and GAME use an explicit `api1-local-recovery` artifact version instead
  of a Git-derived local version. PRODUCT's generated Connector dependency range
  matches that actual version. Whole PRODUCT byte identity is not claimed;
  `evidence/product-delta-analysis.json` records the known metadata difference
  and the limits of comparison without the original PRODUCT binary
- The complete source ZIP has all 674 original file contents unchanged. Its ZIP
  hash differs because empty directories and seven file modes differ after
  archive reconstruction. All 659 identity-covered records verify inside it
- The four-artifact tuple has 1,727 top-level classes and no duplicate class or
  split-package ownership. Native Forge API1 create/reopen is accepted in the
  control worker's separate receipt. Unified/client/C1 claims require their own
  control receipts

## Replay outline

Use a new empty isolated root and the durable API1 package's `restore_sources.py`
first. Do not overlay a live run, accepted world, or C1 source tree. These helper
paths assume this directory is beside `work/api1` and `recovery/api1`.

1. `restore_inputs.py --root ../work/api1` restores the locked public FML inputs,
   official installers and approved toolchain archives. It verifies every hash
   before atomic placement. `prepare_toolchains.py --root ../work/api1` verifies
   and extracts the distributions without running Java
2. Restore `snapshot-lock.json` as well. It fixes the mutable userdev declaration
   to the exact four retained timestamped artifacts in a private local Maven
   directory. The init script restricts that plugin to this local repository
3. Restore `game-input-lock.json`, `forge-server-library-lock.json` and
   `quilt-reference-lock.json`. Minecraft URLs/hashes derive from the original
   1.21.1 metadata whose SHA-256 is
   `458f2fbabc75a1cf79e5853c067f5ad95fca2163941c343b56c5c55b9127c8df`.
   Do not download asset objects or run a client for compile preparation
4. The original 712 artifact/metadata checksum records populate Gradle strict
   verification metadata. Keep strict mode enabled. `run_bounded.py
   installer-client` performs official preparation, then verify all 116 FML
   inputs against the preserved lock before compiling
5. `run_bounded.py gradle-core fullJar :sourcesJar :fml-unified:jar
   :fml-unified:sourcesJar` builds from source and exports the clean named
   Minecraft input through the official binary-only ModDev path. All Java
   processes inherit a 512 MiB cap; one Gradle worker and no parallel Gradle
   tasks are configured. Internal official preparation tools may fork bounded
   helper JVMs; the cap is per JVM, not aggregate resident memory
6. Prepare the official NeoForge and Forge server bases with the corresponding
   `run_bounded.py installer-neo-server` and `installer-forge-server` modes.
   These install distributions only; they do not accept a new EULA or launch a
   game. Verify runtime hashes and reconcile the existing EULA receipt separately
7. Source-build the unchanged basic and API1 Forge probes using their preserved
   scripts and the clean Mojmap input. Expected API1 probe SHA-256:
   `71985bf644262c6c411332f741e25d95b64d5f51800a27c697f4d928470b22c3`
8. `run_bounded.py gradle-core --offline writeProductCompileInputs` produces a
   current-root, hash-recorded compile-only classpath. `build_product.py` verifies
   that classpath and the core tuple, then builds/checks matched PRODUCT. Run
   `run_bounded.py gradle-core --offline check` once after the probe prerequisites
   exist, and verify source identity again

The final tuple and complete source ZIP are in `frozen/`. Receipts and entry
manifests are in `evidence/`. Actual server execution belongs to the separate
`four-loader/api-contract-controls` harness: source-owned installation assembly,
sealed inputs, original resource gate, loopback/no-account settings, bounded
create/save/stop and same-world reopen. A build or native Forge pass is not a
Unified or GUI acceptance result.

These helpers were exercised in the recovered cloud workspace. No remote branch,
workflow or publication was changed by this worker. Source exports should omit
downloaded toolchains, runtime libraries, Minecraft binaries, build outputs and
worlds; retain the locks, licenses, source archives and receipts.
