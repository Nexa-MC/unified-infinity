#!/usr/bin/env python3
"""Read-only match against the durable API1 source and dependency identity."""
import hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent/'work/api1'
PACKAGE=HERE.parent/'recovery/api1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ready=json.loads((PACKAGE/'evidence/integration/ready-receipt.json').read_text())
source=ready['immutableSourceSnapshot']['sources']
for name,digest in source.items():assert sha(ROOT/name)==digest,name
identity=json.loads((PACKAGE/'evidence/integration/build-identity.json').read_text())
for row in identity['sources']:
    name=row['path']
    path=ROOT/'source-workspace'/name[len('loader-sources/'):] if name.startswith('loader-sources/') else ROOT/'source-workspace/connector-four-loader'/name
    assert sha(path)==row['sha256'],str(path)
generated=ROOT/'source-workspace/connector-four-loader/components/infinity-core/build/generated/resources/infinity/META-INF/unified-infinity/build-identity.json'
result={'status':'PASS_DURABLE_SOURCE_MATCH','snapshotRecords':len(source),'coreIdentityRecords':len(identity['sources']),'expectedIdentity':identity['identity_sha256'],'buildIdentityPresent':generated.exists()}
if generated.exists():
    actual=json.loads(generated.read_text());assert actual==identity,'Regenerated identity changed'
    result['regeneratedIdentity']='EXACT_MATCH';result['externalDependencies']=len(actual['dependencies'])
(HERE/'evidence/source-identity-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
