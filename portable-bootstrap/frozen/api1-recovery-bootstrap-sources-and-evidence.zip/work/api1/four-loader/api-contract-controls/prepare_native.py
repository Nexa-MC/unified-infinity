#!/usr/bin/env python3
"""Verify restored official inputs; --prepare alone creates a fresh native profile. No JVM."""
import argparse
import json
import shutil
from common import AREA, ROOT, PROBE, PROBE_SHA, SAFETY_PROPERTIES, checked, local, save_new, sha, utc

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--java', required=True, help='Restored Java 21 executable, project-relative')
    p.add_argument('--prepare', action='store_true')
    p.add_argument('--restore-approved-eula', action='store_true',
                   help='Reconstruct only the previously approved local-test receipt recorded in the preserved native lock')
    a = p.parse_args()
    original_lock = 'four-loader/forge-probe/native-environment-lock.json'
    lock = json.loads(local(original_lock).read_text())
    prefix = 'run/forge-native-probe/'
    rows = [r for r in lock['runtime_files'] if r['path'].startswith(prefix)
            and not r['path'].startswith(prefix + 'defaultconfigs/')]
    missing = [r['path'] for r in rows if not local(r['path']).is_file()]
    missing += [r for r in (PROBE, a.java) if not local(r).is_file()]
    if not local(prefix + 'eula.txt').exists() and not a.restore_approved_eula:
        missing.append(prefix + 'eula.txt (or explicit restoration of preserved approval receipt)')
    if missing:
        print(json.dumps({'status': 'MISSING_RESTORED_INPUTS', 'paths': missing}, indent=2))
        return 2
    for row in rows:
        checked(row['path'], row['sha256'])
    checked(PROBE, PROBE_SHA)
    java = local(a.java)
    release = java.parent.parent / 'release'
    if not any(line.startswith('JAVA_VERSION="21.') for line in release.read_text().splitlines()):
        raise ValueError('Restored official Java 21 required')
    restored_eula = not local(prefix + 'eula.txt').exists()
    if restored_eula:
        if not a.restore_approved_eula or not lock.get('eula_approval'):
            raise ValueError('Preserved EULA approval and explicit receipt restoration required')
    elif local(prefix + 'eula.txt').read_text().strip() != 'eula=true':
        raise ValueError('Existing authorized local-test EULA receipt required')
    print(json.dumps({'status': 'INPUTS_VERIFIED', 'officialRuntimeFiles': len(rows), 'probeSha256': PROBE_SHA, 'willPrepare': a.prepare}))
    if not a.prepare:
        return 0
    profile_relative = 'run/api1-forge-native'
    profile = local(profile_relative)
    manifest = AREA / 'native-server.json'
    if profile.exists() or manifest.exists():
        raise ValueError('Refusing to overwrite a profile or seal')
    profile.mkdir(parents=True)
    files = []
    for row in rows:
        relative = row['path'][len(prefix):]
        dest = profile / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(local(row['path']), dest)
        if sha(dest) != row['sha256']:
            raise ValueError('Copied runtime mismatch: ' + relative)
        files.append({'path': str(dest.relative_to(ROOT)), 'sha256': row['sha256']})
    (profile / 'mods').mkdir()
    dest = profile / 'mods' / local(PROBE).name
    shutil.copyfile(local(PROBE), dest)
    if restored_eula:
        (profile / 'eula.txt').write_text('eula=true\n')
    else:
        shutil.copyfile(local(prefix + 'eula.txt'), profile / 'eula.txt')
    props = dict(SAFETY_PROPERTIES, **{'server-port': '25611', 'view-distance': '2',
        'simulation-distance': '2', 'level-seed': '5210', 'difficulty': 'peaceful',
        'generate-structures': 'false', 'sync-chunk-writes': 'true',
        'pause-when-empty-seconds': '-1', 'max-tick-time': '60000'})
    (profile / 'server.properties').write_text(''.join(k + '=' + v + '\n' for k, v in props.items()))
    (profile / 'defaultconfigs').mkdir()
    (profile / 'defaultconfigs/forge-server.toml').write_text('[server]\nadvertiseDedicatedServerToLan = false\n')
    for relative in (a.java, str(release.relative_to(ROOT)), original_lock,
                     profile_relative + '/eula.txt', profile_relative + '/defaultconfigs/forge-server.toml',
                     'four-loader/launch-support/game_environment.py',
                     'four-loader/api-contract-controls/common.py', 'four-loader/api-contract-controls/run_server.py'):
        files.append({'path': relative, 'sha256': sha(local(relative))})
    result = {'schema': 1, 'loader': 'native-forge', 'minecraft': '1.21.1', 'loaderVersion': '52.1.0',
        'createdUtc': utc(), 'profile': profile_relative, 'java': a.java, 'files': files,
        'libraryInventory': {r['path'].split('/libraries/', 1)[1]: r['sha256'] for r in files if '/libraries/' in r['path']},
        'mods': [{'source': PROBE, 'path': str(dest.relative_to(ROOT)), 'sha256': PROBE_SHA}],
        'serverProperties': props, 'heapMiB': 1280, 'memoryGateBytes': 1879048192,
        'eulaReceipt': {'reconstructedFromPriorApproval': restored_eula,
                        'approvalSource': original_lock, 'approvalText': lock['eula_approval']},
        'command': [a.java, '-Xms256m', '-Xmx1280m', '-XX:ActiveProcessorCount=2',
                    '@libraries/net/minecraftforge/forge/1.21.1-52.1.0/unix_args.txt', 'nogui'],
        'scope': 'Own original Forge API probe: real server startup, console save, clean exit and same-world reopen; no player or broad persistence claim.'}
    save_new(manifest, result)
    print(json.dumps({'manifest': str(manifest.relative_to(ROOT)), 'sha256': sha(manifest), 'gameLaunched': False}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
