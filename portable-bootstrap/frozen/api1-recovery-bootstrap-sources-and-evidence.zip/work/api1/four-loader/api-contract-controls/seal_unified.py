#!/usr/bin/env python3
"""Seal the builder's existing server assembly for controlled console acceptance. No JVM."""
import argparse
import json
from pathlib import Path
from common import AREA, ROOT, PROBE, PROBE_SHA, REQUIRED_BYTES, checked, load_module, local, properties, save_new, sha, tree, utc
from run_server import check

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--spec', required=True)
    p.add_argument('--spec-sha256', required=True)
    p.add_argument('--receipt', required=True)
    p.add_argument('--receipt-sha256', required=True)
    args = p.parse_args()
    a = load_module('api1_seal_assembler', 'source-workspace/fml-unified/tools/assemble_installation.py')
    plan = a.load_pinned(checked(args.spec, args.spec_sha256), args.spec_sha256)
    policy, command, java = a.prepare(plan)
    profile = Path(plan['gameDirectory'])
    relative_profile = str(profile.relative_to(ROOT))
    java_relative = str(Path(java).relative_to(ROOT))
    if (profile / 'world').exists():
        raise ValueError('Server control must be sealed before any world exists')
    files = []
    for relative in (args.spec, args.receipt, java_relative,
                     relative_profile + '/eula.txt', relative_profile + '/defaultconfigs/neoforge-server.toml',
                     relative_profile + '/config/neoforge-server.toml',
                     'four-loader/launch-support/game_environment.py',
                     'source-workspace/fml-unified/tools/assemble_installation.py',
                     'source-workspace/fml-unified/tools/validate_launch.py'):
        files.append({'path': relative, 'sha256': sha(local(relative))})
    for path in (AREA / 'common.py', AREA / 'run_server.py'):
        files.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(path)})
    manifest = {'schema': 1, 'createdUtc': utc(), 'loader': 'unified', 'minecraft': '1.21.1',
        'profile': relative_profile, 'java': java_relative,
        'command': [java_relative, *command], 'files': files,
        'libraryInventory': tree(profile / 'libraries'),
        'heapMiB': 1280, 'memoryGateBytes': REQUIRED_BYTES,
        'serverProperties': properties(profile / 'server.properties'),
        'mods': [{'source': PROBE, 'path': relative_profile + '/mods/' + local(PROBE).name, 'sha256': PROBE_SHA}],
        'unified': {'spec': args.spec, 'specSha256': args.spec_sha256,
                    'receipt': args.receipt, 'receiptSha256': args.receipt_sha256},
        'scope': 'Same original Forge API probe under source-owned Unified FML; real server startup/save/reopen, no broad compatibility claim.'}
    check(manifest)
    output = AREA / 'unified-server.json'
    save_new(output, manifest)
    print(json.dumps({'manifest': str(output.relative_to(ROOT)), 'sha256': sha(output), 'gameLaunched': False}))

if __name__ == '__main__':
    main()
