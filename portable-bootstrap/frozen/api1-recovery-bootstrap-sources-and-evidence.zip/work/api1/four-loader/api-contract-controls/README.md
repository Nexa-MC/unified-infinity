# Recovered API1 controls

These scripts were reconstructed on 2026-10-05 after the cloud workspace reset.
They are source-only preparation, not recovered runtime passes. Include this
entire directory's Python/Markdown/JSON sources in the next durable source
checkpoint; exclude generated worlds, libraries, bytecode caches and credentials.
The repository root is derived from each script's location, not an old absolute
workspace path. Generated seals must be regenerated for a new installation root.

## Ownership and prerequisites

The build worker owns official Java/dependency restoration, all compilation,
`run/forge-native-probe`, `run/neoforge-native`, and `run/client-dev`. This control
owns `run/api1-forge-native`, `run/api1-unified-server`, and its own evidence.
Never start a JVM while the build slot is held. Actual game execution requires
the coordinator's slot release and the fresh native-terminal gate, with exactly
1280 MiB heap plus 512 MiB reserve: 1,879,048,192 eligible bytes and no live JVM.
The script permits no lower budget, active-file credit, or invented DISPLAY.

Required Forge inputs:

- Official Forge 1.21.1-52.1.0 installed server closure, checked against the
  preserved `four-loader/forge-probe/native-environment-lock.json` runtime hashes
- Official installer SHA-256
  `f1b620f2879ad6a5bbe15daba4d8f81eab9f5e08004967604960b98996bdebc4`
- Recovered original self-authored Forge API probe at
  `four-loader/forge-api-probe/build/unified-forge-api-probe-0.1.0.jar`, SHA-256
  `71985bf644262c6c411332f741e25d95b64d5f51800a27c697f4d928470b22c3`
- Official Java 21 restored and pinned by the builder, plus the previously approved local-test EULA receipt, either recovered or explicitly
  reconstructed from the preserved native lock and the coordinator’s reaffirmation

The probe JAR was absent from the recovered source archive. Rebuild it once from
the unchanged recipe after compile inputs/toolchain are restored, then verify
the historical hash. A different hash is a reported blocker, not silent
equivalence. Both controls must execute the same frozen original bytes.

## Native Forge preparation and controls

From the repository root, verification only (no profile mutation or JVM):

```
python four-loader/api-contract-controls/prepare_native.py --java .toolchains/jdk-21.0.12.1+1/bin/java
```

Use the builder's actual project-relative Java path if that restored location
differs. Add `--prepare` only after inputs are verified. If the EULA file was lost on reset,
`--restore-approved-eula` records reconstruction from the preserved prior approval;
it does not claim the original file was recovered or accept new terms. Preparation refuses an
existing profile/seal and creates independent runtime copies, one probe, a fresh
world location, loopback port 25611, empty-whitelist enforcement, and disabled
query/RCON/status/LAN advertisement. Native Forge uses the `[server]` table;
NeoForge uses its root property. The sealed launch also caps active processors at two. It never runs an installer or Minecraft.
Record the printed new `native-server.json` hash as `<seal-sha>`.

```
python four-loader/api-contract-controls/run_server.py --manifest four-loader/api-contract-controls/native-server.json --sha256 <seal-sha> --phase create
```

That command validates only. After the runtime slot is explicitly released, run
it from the actual cloud desktop terminal with `--execute --runtime-slot-approved`.
Then run the same seal with `--phase reopen` and the same explicit launch flags.
Do not overwrite a failed phase. A reviewed new profile/seal is needed for a new
attempt; no automated retries are provided.

## Matched source-owned Unified server

The build worker must produce a new server-specific FML installation spec and
receipt on NeoForge 21.1.219/FML 4.0.42. FML remains the sole admission owner.
Do not transplant a previous client launch spec or preload flags. Requirements:

- Fresh `run/api1-unified-server`, server launch target and `nogui`
- `heapMiB=1280`, `memoryGateBytes=1879048192`, `firstLaunchOnly=false`; the
  control harness independently permits exactly one create and one reopen
- Exactly the same original Forge API probe as user input; managed artifacts
  may appear in `mods` only when owned by the validated installation policy
- Port 25612, the same loopback/whitelist settings and `level-name=world`
- Both `config/neoforge-server.toml` and
  `defaultconfigs/neoforge-server.toml` disable dedicated LAN advertisement

After source assembly and static launch validation:

```
python four-loader/api-contract-controls/seal_unified.py --spec <relative-spec> --spec-sha256 <sha> --receipt <relative-receipt> --receipt-sha256 <sha>
```

Run `run_server.py` exactly as above using `unified-server.json` and its printed
hash. The existing `assemble_installation.prepare` and `validate_launch.validate`
must pass again immediately before the harness's fresh gate and spawn. The
closed environment is the existing `launch-support/game_environment.py` policy;
it is environment hygiene, not a filesystem or network sandbox.

## Required evidence and limits

Each actual process must emit exactly once and in order:

```
UNIFIED_FORGE_API_PROBE PASS stage=before_binding
UNIFIED_FORGE_API_PROBE PASS stage=after_binding
UNIFIED_FORGE_API_PROBE PASS stage=common_setup
UNIFIED_FORGE_API_PROBE PASS stage=queued_supplier
UNIFIED_FORGE_API_PROBE PASS stage=ready
```

The harness also requires the exact loopback bind, vanilla `Done`, console
`save-all flush` followed by a later save acknowledgment, `stop`, all-dimensions
saved, exit zero, `world/level.dat` and region data. It hashes the complete stopped
world, requires that exact tree before reopening, and rechecks original and
runtime inputs after each process. The probe does not write a persistent marker:
these controls prove same-world reopen and repeated API behavior, not broad
mod-data persistence. Approved mixed-world regression remains a separate gate.
No menu-only, performance, client, arbitrary Forge API or all-mods claim follows.

Complete console and started/gate/result receipts are written exclusively under
`evidence/<profile>/<create|reopen>`. The runner only stops its own spawned
process on timeout/failure. It never terminates unknown processes or drops caches.

## Quilt follow-on, not yet reconstructed/launched

Original intermediary probe SHA-256:
`9106f5a6629d3e3f2206bc967d77aaff228f67ef6e216cd8f27f79139e743dfe`.
Official Quilt Loader 0.30.1 and QSL 10.0.0-alpha.5+1.21.1 base/lifecycle/tooltip
are required. Module hashes and compile closure remain in the original
`four-loader/quilt-api-probe/build.py` and README; do not substitute host facades.

The old native development route used official Quilt Loom 1.8.5 with Yarn
1.21.1+build.3-v2, mappings SHA-256
`0656f2619dc6e63f1fbfb06c2e4eaf541cec91853afb8ecd37588b229eca40f7`.
Its original intermediary probe was mapped to a named derivative. Original input
equality does not mean byte-identical runtime JARs. Record original-to-derived
hashes and exact mapping inputs anew; do not reuse an absent historical cache or
manually rewrite the fixture source. Mapping is JVM work requiring the slot.

Client evidence must include `stage=direct_requests item_requests=2
component_requests=6`, all per-request labels/counters, provider identity,
actual Minecraft target calls, and no duplicate callbacks or Mixin failures.
In a disposable creative world, give and hover the probe's `convertible` and
`plain` items. Check vanilla lines followed by manual and automatic markers;
convertible also shows `QSL convertible component`. Save and exit. A separately
sealed reopened/copy-preserved world with
`-Dunified.quiltTooltipProbe.override=true` must visibly show
`QSL default-phase override component`. Cache reuse requires actual validated
hit evidence, not merely copied cache files.

Dedicated Quilt/Unified controls must use the common probe, verify
`stage=server_side_linkage`, actual removal of the implementing `@ClientOnly`
method and absence of client-class definitions, plus independent server
startup/save/reopen. Admission negatives use bounded static admission harnesses.

## Local verification

```
python -m unittest discover -s four-loader/api-contract-controls -p 'test_*.py' -v
```

Eight pure-Python log/config-evidence tests cover missing, duplicate, reordered, wrong
binding and failure-after-pass cases. Their success is not a JVM/game pass.
These helpers currently target Linux/native cgroup v2 and POSIX console pipes.
Windows would require an independently reviewed memory/process gate and official
`win_args.txt` handling; no Windows portability or launch claim is made.
