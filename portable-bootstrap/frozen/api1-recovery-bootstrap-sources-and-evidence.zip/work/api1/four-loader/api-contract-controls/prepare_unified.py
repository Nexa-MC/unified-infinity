#!/usr/bin/env python3
"""Build a fresh server-specific source-owned installation from pinned official/build receipts. No JVM."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shlex
import shutil
import tomllib
import zipfile
from common import AREA, ROOT, PROBE, PROBE_SHA, SAFETY_PROPERTIES, checked, load_module, local, save_new, sha, utc

OFFICIAL_LOCK = 'four-loader/forge-probe/unified-forge-probe-final26b-environment-lock.json'
BASE = ROOT / 'run/neoforge-native'
PROFILE = ROOT / 'run/api1-unified-server'
STOCK_FML = 'net/neoforged/fancymodloader/loader/4.0.42/loader-4.0.42.jar'

def descriptor(archive):
    names = set(archive.namelist())
    neo, forge = 'META-INF/neoforge.mods.toml' in names, 'META-INF/mods.toml' in names
    config = tomllib.loads(archive.read('META-INF/neoforge.mods.toml' if neo else 'META-INF/mods.toml').decode()) if neo or forge else {}
    if neo and 'fabric.mod.json' in names and 'connector:placeholder' in config.get('properties', {}):
        neo = False
    children = []
    if neo or forge:
        ids = [row['modId'] for row in config.get('mods', [])]
    elif 'quilt.mod.json' in names or 'fabric.mod.json' in names:
        quilt = 'quilt.mod.json' in names
        meta = json.loads(archive.read('quilt.mod.json' if quilt else 'fabric.mod.json'))
        loader = meta['quilt_loader'] if quilt else meta
        ids = [loader['id']]
        children += [row if isinstance(row, str) else row['file'] for row in loader.get('jars', [])]
    else:
        ids = []
    if 'META-INF/jarjar/metadata.json' in names:
        children += [row['path'] for row in json.loads(archive.read('META-INF/jarjar/metadata.json'))['jars']]
    if 'META-INF/unified-infinity/bundled-qsl.json' in names:
        children += [row['path'] for row in json.loads(archive.read('META-INF/unified-infinity/bundled-qsl.json'))['modules']]
    if len(names) != len(archive.namelist()) or len(children) != len(set(children)):
        raise ValueError('Duplicate archive or nested entry')
    return ids, children

def embedded(root_relative, source, chain=()):
    with zipfile.ZipFile(source) as archive:
        ids, children = descriptor(archive)
        result = []
        for name in children:
            if name.startswith('/') or '\\' in name or '..' in Path(name).parts or len(chain) >= 8:
                raise ValueError('Invalid nested path')
            if archive.getinfo(name).file_size > 32 * 1024 * 1024:
                raise ValueError('Oversized nested archive')
            raw = archive.read(name)
            entries = (*chain, name)
            with zipfile.ZipFile(io.BytesIO(raw)) as child:
                child_ids, _ = descriptor(child)
            api = root_relative == 'installation/product.jar' and bool(child_ids) and (
                child_ids[0].startswith('quilt_') or ('forgified-fabric-api-' in entries[0] and not any('forgified-fabric-loader-' in entry for entry in entries)))
            result.append({'root': root_relative, 'entries': list(entries),
                'sha256': hashlib.sha256(raw).hexdigest(), 'primaryIds': child_ids,
                'role': 'BUNDLED_API' if api else 'PLATFORM',
                'apiFamily': ('QSL' if child_ids[0].startswith('quilt_') else 'FFAPI') if api else None})
            result += embedded(root_relative, io.BytesIO(raw), entries)
    return result

def pinned_json(path, digest):
    if sha(path) != digest:
        raise ValueError('Changed build receipt: ' + str(path))
    return json.loads(path.read_text())

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tuple', type=Path, required=True)
    p.add_argument('--tuple-sha256', required=True)
    p.add_argument('--base-receipt', type=Path, required=True)
    p.add_argument('--base-receipt-sha256', required=True)
    p.add_argument('--prepare', action='store_true')
    args = p.parse_args()
    builds = pinned_json(args.tuple, args.tuple_sha256)
    receipt = pinned_json(args.base_receipt, args.base_receipt_sha256)
    for role in ('service', 'game', 'fml', 'product'):
        row = builds[role]
        if sha(Path(row['path'])) != row['sha256']:
            raise ValueError('Changed source artifact: ' + role)
    if receipt['sha256'] != builds['fml']['sha256']:
        raise ValueError('FML receipt and tuple disagree')
    checked(PROBE, PROBE_SHA)
    official = json.loads(local(OFFICIAL_LOCK).read_text())
    rows = [(r['path'].split('/libraries/', 1)[1], r['sha256']) for r in official['runtime_files'] if '/libraries/' in r['path']]
    for relative, digest in rows:
        if sha(BASE / 'libraries' / relative) != digest:
            raise ValueError('Official restored library differs: ' + relative)
    java = ROOT / '.toolchains/jdk-21.0.12.1+1/bin/java'
    argfile = BASE / 'libraries/net/neoforged/neoforge/21.1.219/unix_args.txt'
    verifier = load_module('api1_bundle_verifier', 'runtime-bundle/tools/verify_bundle.py')
    verifier.verify(Path(builds['product']['path']), ROOT / 'docs/research/upstream/ffapi-baseline.jar',
                    ROOT / 'docs/four-loader/quilt/bundled-tooltip.json')
    print(json.dumps({'status': 'SOURCE_TUPLE_AND_OFFICIAL_INPUTS_VERIFIED', 'officialFiles': len(rows), 'willPrepare': args.prepare}))
    if not args.prepare:
        return
    output = AREA / 'unified-assembly'
    if PROFILE.exists() or output.exists():
        raise ValueError('Refusing to overwrite a profile or assembly')
    PROFILE.mkdir(parents=True); output.mkdir()
    (PROFILE / 'installation').mkdir()
    artifacts, replacements = [], {}
    for relative, digest in rows:
        old = BASE / 'libraries' / relative
        new = PROFILE / 'libraries' / relative
        if relative == STOCK_FML:
            replacements[str(old)] = str(PROFILE / 'installation/boot.jar')
            continue
        new.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(old, new)
        replacements[str(old)] = str(new)
        if new.suffix == '.jar':
            with zipfile.ZipFile(new) as archive:
                ids, _ = descriptor(archive)
            artifacts.append({'path': str(new.relative_to(PROFILE)), 'sha256': digest,
                'primaryIds': ids, 'role': 'PLATFORM', 'provenance': {'lock': OFFICIAL_LOCK, 'source': str(old)}})
    for role, policy_role in (('service', 'ADMISSION_CONSUMER'), ('game', 'COMPATIBILITY_GAME'), ('product', 'PRODUCT_GAME')):
        row = builds[role]; new = PROFILE / 'installation' / (role + '.jar')
        shutil.copyfile(row['path'], new)
        with zipfile.ZipFile(new) as archive:
            ids, _ = descriptor(archive)
        artifacts.append({'path': str(new.relative_to(PROFILE)), 'sha256': row['sha256'],
            'primaryIds': ids, 'role': policy_role, 'provenance': {'buildTupleSha256': args.tuple_sha256, 'source': row['path']}})
    artifacts.append({'path': 'installation/boot.jar', 'sha256': 'SELF', 'primaryIds': [],
        'role': 'BOOT_OWNER', 'provenance': {'baseReceiptSha256': args.base_receipt_sha256, 'compiledSourceSha256': receipt['sha256']}})
    nested = []
    for artifact in artifacts:
        if artifact['role'] != 'BOOT_OWNER':
            nested += embedded(artifact['path'], PROFILE / artifact['path'])
    api_pins = [row for row in nested if row['role'] == 'BUNDLED_API']
    if len(api_pins) != 46 or sum(len(row['primaryIds']) for row in api_pins) != 47:
        raise ValueError('Unexpected bundled API archive/logical-ID closure')
    tokens = shlex.split(argfile.read_text(), comments=True)
    for index, token in enumerate(tokens):
        if index and tokens[index - 1] in ('-p', '-cp', '--module-path', '--class-path'):
            tokens[index] = ':'.join(str((BASE / path).resolve()) for path in token.split(':'))
        elif token.startswith('-DlegacyClassPath='):
            tokens[index] = '-DlegacyClassPath=' + ':'.join(str((BASE / path).resolve()) for path in token.split('=', 1)[1].split(':'))
        elif token.startswith('-DlibraryDirectory='):
            tokens[index] = '-DlibraryDirectory=' + str(BASE / 'libraries')
    launch = {'workingDirectory': str(BASE),
        'command': [str(java), '-Xms256m', '-Xmx1280m', '-XX:ActiveProcessorCount=2', *tokens, 'nogui'],
        'files': [{'path': str(argfile), 'sha256': sha(argfile)}, {'path': str(java), 'sha256': sha(java)}],
        'provenance': 'Pinned official NeoForge server unix_args; only explicit path absolutization, heap and processor budget; no game launch.'}
    launch_path = output / 'official-server-launch.json'; save_new(launch_path, launch)
    (PROFILE / 'mods').mkdir()
    probe = PROFILE / 'mods' / local(PROBE).name
    shutil.copyfile(local(PROBE), probe)
    (PROFILE / 'eula.txt').write_text('eula=true\n')
    for directory in ('config', 'defaultconfigs'):
        (PROFILE / directory).mkdir()
        (PROFILE / directory / 'neoforge-server.toml').write_text('advertiseDedicatedServerToLan = false\n')
    props = dict(SAFETY_PROPERTIES, **{'server-port': '25612', 'view-distance': '2',
        'simulation-distance': '2', 'level-seed': '5210', 'difficulty': 'peaceful',
        'generate-structures': 'false', 'sync-chunk-writes': 'true', 'max-tick-time': '60000'})
    (PROFILE / 'server.properties').write_text(''.join(k + '=' + v + '\n' for k, v in props.items()))
    spec = {'installationDirectory': str(PROFILE), 'gameDirectory': str(PROFILE),
        'policyId': 'api1-recovered-forge-api-server-20261005', 'launchTarget': 'forgeserver',
        'launchSource': {'path': str(launch_path), 'sha256': sha(launch_path)},
        'pathReplacements': replacements, 'artifacts': artifacts, 'embedded': nested,
        'heapMiB': 1280, 'memoryGateBytes': 1879048192, 'firstLaunchOnly': False,
        'userMods': [{'source': str(local(PROBE)), 'path': str(probe), 'sha256': PROBE_SHA}],
        'classLoadLog': str(PROFILE / 'class-load.log'),
        'eulaReceipt': {'basis': 'Prior approved local cloud game testing, reaffirmed by coordinator; reconstructed file after reset.'}}
    spec_path = output / 'server-spec.json'; save_new(spec_path, spec)
    assembler = load_module('api1_server_assembler', 'source-workspace/fml-unified/tools/assemble_installation.py')
    result = assembler.assemble(spec_path, sha(spec_path), args.base_receipt, args.base_receipt_sha256, output / 'configured')
    save_new(output / 'construction-result.json', {'utc': utc(), 'spec': str(spec_path.relative_to(ROOT)),
        'specSha256': sha(spec_path), 'tupleSha256': args.tuple_sha256, 'embeddedApiArchives': len(api_pins),
        'embeddedApiIds': sum(len(row['primaryIds']) for row in api_pins),
        'embeddedPlatformArchives': sum(row['role'] == 'PLATFORM' for row in nested), 'assembly': result})
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
