"""Pure Python acceptance-parser negatives. These never launch a JVM or game."""
import unittest
from common import STAGES, lan_disabled, summarize

def transcript(stages=STAGES, binding='127.0.0.1:25611'):
    return ('\n'.join('UNIFIED_FORGE_API_PROBE PASS stage=' + stage + ' count=1' for stage in stages)
        + '\nStarting Minecraft server on ' + binding
        + '\nDone (1.0s)! For help, type "help"'
        + '\nSaved the game\nAll dimensions are saved\n').encode()

class EvidenceTests(unittest.TestCase):
    def test_loader_specific_lan_config_contract(self):
        self.assertTrue(lan_disabled({'server': {'advertiseDedicatedServerToLan': False}}, 'native-forge'))
        self.assertFalse(lan_disabled({'advertiseDedicatedServerToLan': False}, 'native-forge'))
        self.assertTrue(lan_disabled({'advertiseDedicatedServerToLan': False}, 'unified'))
        self.assertFalse(lan_disabled({'server': {'advertiseDedicatedServerToLan': False}}, 'unified'))
    def test_complete_exact_control(self):
        s = summarize(transcript(), 25611)
        self.assertTrue(all(s[k] for k in ('stagesExactAndOrdered', 'serverReady', 'loopbackBinding', 'saved', 'allDimensionsSaved')))
        self.assertFalse(s['failures'])

    def test_each_missing_stage_rejected(self):
        for stage in STAGES:
            self.assertFalse(summarize(transcript([s for s in STAGES if s != stage]), 25611)['stagesExactAndOrdered'])

    def test_duplicate_and_wrong_order_rejected(self):
        for stages in (STAGES + ['ready'], list(reversed(STAGES))):
            self.assertFalse(summarize(transcript(stages), 25611)['stagesExactAndOrdered'])

    def test_prefix_does_not_count(self):
        raw = transcript().replace(b'stage=ready ', b'stage=ready_extra ')
        self.assertFalse(summarize(raw, 25611)['stagesExactAndOrdered'])

    def test_unsafe_wrong_or_duplicate_binding_rejected(self):
        for binding in ('0.0.0.0:25611', '*:25611', '127.0.0.1:25612'):
            self.assertFalse(summarize(transcript(binding=binding), 25611)['loopbackBinding'])
        self.assertFalse(summarize(transcript() + b'Starting Minecraft server on 127.0.0.1:25611\n', 25611)['loopbackBinding'])

    def test_pass_does_not_hide_failure(self):
        self.assertTrue(summarize(transcript() + b'UNIFIED_FORGE_API_PROBE FAIL reason=x\n', 25611)['failures'])

    def test_menu_or_partial_shutdown_is_not_acceptance(self):
        s = summarize(b'UNIFIED_FORGE_API_PROBE PASS stage=common_setup\n', 25611)
        self.assertFalse(s['serverReady'] or s['saved'] or s['allDimensionsSaved'])
        self.assertFalse(summarize(transcript().replace(b'All dimensions are saved', b'Stopping server'), 25611)['allDimensionsSaved'])

if __name__ == '__main__':
    unittest.main()
