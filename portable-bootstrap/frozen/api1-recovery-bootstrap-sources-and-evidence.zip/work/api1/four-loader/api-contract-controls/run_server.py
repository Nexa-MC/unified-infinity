#!/usr/bin/env python3
"""Validate an immutable control seal; start one bounded server only with --execute."""
import argparse
import fcntl
import json
import os
import select
import socket
import subprocess
import time
import tomllib
from pathlib import Path
from common import (AREA, ROOT, PROBE, PROBE_SHA, REQUIRED_BYTES, SAFETY_PROPERTIES,
    checked, environment, lan_disabled, load_module, local, memory_gate, properties, save_new, sha, summarize, tree, utc)

def check(manifest):
    profile = local(manifest['profile'])
    if profile.parent != ROOT / 'run' or not profile.name.startswith('api1-'):
        raise ValueError('An isolated api1 profile is required')
    if manifest['heapMiB'] != 1280 or manifest['memoryGateBytes'] != REQUIRED_BYTES:
        raise ValueError('Original 1280 MiB plus 512 MiB budget required')
    for row in manifest['files']:
        checked(row['path'], row['sha256'])
    if tree(profile / 'libraries') != manifest['libraryInventory']:
        raise ValueError('Runtime library inventory changed')
    expected = {}
    for row in manifest['mods']:
        checked(row['source'], row['sha256'])
        dest = checked(row['path'], row['sha256'])
        if dest.parent != profile / 'mods' or dest.name in expected:
            raise ValueError('Unexpected or repeated probe destination')
        expected[dest.name] = row['sha256']
    if expected != {local(PROBE).name: PROBE_SHA}:
        raise ValueError('This bounded server phase requires exactly the original Forge API probe')
    if (profile / 'eula.txt').read_text().strip() != 'eula=true':
        raise ValueError('Existing EULA receipt required')
    props = properties(profile / 'server.properties')
    for key, value in {**manifest['serverProperties'], **SAFETY_PROPERTIES}.items():
        if props.get(key) != value:
            raise ValueError('Server setting changed: ' + key)
    config = 'forge-server.toml' if manifest['loader'] == 'native-forge' else 'neoforge-server.toml'
    for relative in ('defaultconfigs/' + config, 'world/serverconfig/' + config):
        path = profile / relative
        if (relative.startswith('defaultconfigs/') or path.exists()) and not lan_disabled(tomllib.loads(path.read_text()), manifest['loader']):
            raise ValueError('Dedicated LAN advertisement must be disabled')
    java = local(manifest['java'])
    env = environment.build_game_environment(os.environ, profile, java.parent.parent, {})
    command = [str(java), *manifest['command'][1:]]
    if manifest['command'][0] != manifest['java'] or '-Xmx1280m' not in command:
        raise ValueError('Sealed executable/heap mismatch')
    if manifest['loader'] == 'unified':
        a = load_module('api1_assembler', 'source-workspace/fml-unified/tools/assemble_installation.py')
        u = manifest['unified']
        plan = a.load_pinned(checked(u['spec'], u['specSha256']), u['specSha256'])
        policy, args, executable = a.prepare(plan)
        if plan.get('firstLaunchOnly') or plan['heapMiB'] != 1280 or plan['memoryGateBytes'] != REQUIRED_BYTES:
            raise ValueError('Dedicated create/reopen plan budget or phase policy mismatch')
        if not plan['launchTarget'].endswith('server') or 'nogui' not in args:
            raise ValueError('Server-specific source assembly required')
        if policy['gameDirectory'] != str(profile) or [executable, *args] != command:
            raise ValueError('Source-owned launch differs from server control seal')
        if plan.get('expectedExcludedInputs'):
            raise ValueError('Admission negatives require a separate control')
        if {(r['source'], r['path'], r['sha256']) for r in plan['userMods']} != {
            (str(local(r['source'])), str(local(r['path'])), r['sha256']) for r in manifest['mods']}:
            raise ValueError('Source assembly user-mod set differs')
        a.v.validate(checked(u['receipt'], u['receiptSha256']), u['receiptSha256'], args, env)
        for artifact in policy['artifacts']:
            path = Path(policy['installationDirectory']) / artifact['path']
            if path.parent == profile / 'mods':
                if path.name in expected:
                    raise ValueError('Managed artifact overlaps original probe')
                expected[path.name] = sha(path)
        if tomllib.loads((profile / 'config/neoforge-server.toml').read_text()).get('advertiseDedicatedServerToLan') is not False:
            raise ValueError('NeoForge root LAN advertisement must be off')
    elif manifest['loader'] != 'native-forge':
        raise ValueError('Unsupported control loader')
    if tree(profile / 'mods') != expected:
        raise ValueError('Original/managed mod inventory changed')
    return profile, command, env, int(props['server-port'])

def run(manifest, seal_sha, phase, destination, timeout):
    profile, command, env, port = check(manifest)
    world = profile / 'world'
    before = tree(world)
    if phase == 'create' and world.exists():
        raise ValueError('Create requires a fresh world')
    if phase == 'reopen':
        previous = json.loads((destination.parent / 'create' / 'result.json').read_text())
        if not previous['passed'] or previous['manifestSha256'] != seal_sha or previous['worldAfter'] != before:
            raise ValueError('Reopen requires the unchanged world from this sealed successful create')
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', port))
    destination.mkdir(parents=True, exist_ok=False)
    report = {'utc': utc(), 'phase': phase, 'manifestSha256': seal_sha,
        'profile': manifest['profile'], 'command': command, 'worldBefore': before,
        'passed': False, 'gameLaunched': False, 'saveRequested': False,
        'saveAcknowledgedAfterRequest': False, 'stopRequested': False,
        'environmentPolicy': environment.public_policy_descriptor()}
    process = None
    raw = bytearray()
    try:
        with (profile / 'api1-control.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if not os.environ.get('DISPLAY') or not os.isatty(0):
                raise ValueError('Launch must originate in the real native desktop terminal')
            environment.create_private_environment_directories(profile)
            gate = memory_gate()
            save_new(destination / 'launch-gate.json', gate)
            if not gate['passed']:
                raise ValueError('Native headroom/JVM gate blocked; no game started')
            with (destination / 'console.log').open('xb') as output:
                process = subprocess.Popen(command, cwd=profile, env=env, stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
                report.update(gameLaunched=True, pid=process.pid, startedUtc=utc())
                save_new(destination / 'started.json', report)
                print(json.dumps({'started': True, 'pid': process.pid, 'phase': phase, 'evidence': str(destination)}), flush=True)
                deadline = time.monotonic() + timeout
                while process.poll() is None:
                    if time.monotonic() >= deadline:
                        raise TimeoutError('Server control exceeded its bounded deadline')
                    readable, _, _ = select.select([process.stdout], [], [], .25)
                    if not readable:
                        continue
                    chunk = os.read(process.stdout.fileno(), 65536)
                    if not chunk:
                        continue
                    output.write(chunk); output.flush(); raw.extend(chunk)
                    if len(raw) > 32 * 1024 * 1024:
                        raise RuntimeError('Bounded console inspection limit exceeded')
                    observed = summarize(raw, port)
                    if observed['failures']:
                        raise RuntimeError('Probe or loading failure; inspect complete console log')
                    if observed['serverReady'] and observed['stagesExactAndOrdered'] and observed['loopbackBinding'] and not report['saveRequested']:
                        process.stdin.write(b'save-all flush\n'); process.stdin.flush()
                        report['saveRequested'] = True
                        report['saveLogOffset'] = len(raw)
                    if report['saveRequested'] and not report['stopRequested'] and summarize(raw[report['saveLogOffset']:], port)['saved']:
                        report['saveAcknowledgedAfterRequest'] = True
                        process.stdin.write(b'stop\n'); process.stdin.flush()
                        report['stopRequested'] = True
                tail = process.stdout.read() or b''
                output.write(tail); raw.extend(tail)
            observed = summarize(raw, port)
            report.update(observed=observed, exitCode=process.wait())
            check(manifest)
            report['inputsUnchanged'] = True
            report['passed'] = (report['exitCode'] == 0 and report['saveAcknowledgedAfterRequest']
                and report['stopRequested'] and observed['stagesExactAndOrdered'] and not observed['failures']
                and observed['serverReady'] and observed['loopbackBinding'] and observed['allDimensionsSaved']
                and (world / 'level.dat').is_file() and bool(list((world / 'region').glob('*.mca'))))
    except Exception as error:
        report['failure'] = type(error).__name__ + ': ' + str(error)
    finally:
        if process is not None and process.poll() is None:
            try:
                tail, _ = process.communicate(input=b'stop\n', timeout=15)
            except (BrokenPipeError, OSError, subprocess.TimeoutExpired):
                process.terminate()
                try:
                    tail, _ = process.communicate(timeout=15)
                except subprocess.TimeoutExpired:
                    process.kill(); tail, _ = process.communicate()
            if tail:
                with (destination / 'console.log').open('ab') as output:
                    output.write(tail)
                raw.extend(tail)
            report['exitCode'] = process.returncode
        report['observed'] = summarize(raw, port)
        report['worldAfter'] = tree(world)
        report['finishedUtc'] = utc()
        if (destination / 'console.log').exists():
            report['logSha256'] = sha(destination / 'console.log')
        save_new(destination / 'result.json', report)
    print(json.dumps({'passed': report['passed'], 'failure': report.get('failure'), 'result': str(destination / 'result.json')}))
    return 0 if report['passed'] else 1

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', required=True)
    p.add_argument('--sha256', required=True)
    p.add_argument('--phase', choices=['create', 'reopen'], required=True)
    p.add_argument('--timeout', type=int, default=600)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--runtime-slot-approved', action='store_true')
    a = p.parse_args()
    manifest = json.loads(checked(a.manifest, a.sha256).read_text())
    check(manifest)
    if not a.execute:
        print(json.dumps({'status': 'STATIC_INPUTS_AND_LAUNCH_VERIFIED', 'gameLaunched': False}))
        return 0
    if not a.runtime_slot_approved or not 60 <= a.timeout <= 600:
        raise ValueError('Exclusive runtime slot and bounded timeout required')
    destination = AREA / 'evidence' / local(manifest['profile']).name / a.phase
    return run(manifest, a.sha256, a.phase, destination, a.timeout)

if __name__ == '__main__':
    raise SystemExit(main())
