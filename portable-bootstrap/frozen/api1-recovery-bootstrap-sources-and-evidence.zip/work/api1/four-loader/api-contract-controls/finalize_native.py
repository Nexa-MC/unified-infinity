#!/usr/bin/env python3
"""Reconcile both completed native controls and capture final native JVM inventory. No JVM."""
import json
import os
from common import AREA, ROOT, PROBE_SHA, memory_gate, save_new, sha, summarize, tree, utc
from run_server import check

if not os.environ.get('DISPLAY') or not os.isatty(0):
    raise SystemExit('Run this final resource observation in the native desktop terminal')
seal = AREA / 'native-server.json'
manifest = json.loads(seal.read_text())
profile, _, _, port = check(manifest)
evidence = AREA / 'evidence' / profile.name
reports = {}
for phase in ('create', 'reopen'):
    path = evidence / phase / 'result.json'
    report = json.loads(path.read_text())
    log = evidence / phase / 'console.log'
    observed = summarize(log.read_bytes(), port)
    if not report['passed'] or report['exitCode'] != 0 or report['manifestSha256'] != sha(seal):
        raise SystemExit('Phase receipt mismatch or failure: ' + phase)
    if sha(log) != report['logSha256'] or observed != report['observed']:
        raise SystemExit('Phase log changed: ' + phase)
    reports[phase] = report
if reports['create']['worldAfter'] != reports['reopen']['worldBefore']:
    raise SystemExit('World continuity mismatch')
if tree(profile / 'world') != reports['reopen']['worldAfter']:
    raise SystemExit('Stopped world changed after reopen')
gate = memory_gate()
if gate['liveJvms']:
    raise SystemExit('A JVM is still active; do not release the runtime slot')
result = {'utc': utc(), 'status': 'NATIVE_FORGE_API1_CREATE_REOPEN_PASS',
    'probeSha256': PROBE_SHA, 'manifestSha256': sha(seal), 'worldContinuity': True,
    'phases': {phase: {'result': str((evidence / phase / 'result.json').relative_to(ROOT)),
        'resultSha256': sha(evidence / phase / 'result.json'),
        'logSha256': report['logSha256'], 'startedUtc': report['startedUtc'],
        'finishedUtc': report['finishedUtc'], 'exitCode': report['exitCode'],
        'stages': report['observed']['stages'], 'worldFiles': len(report['worldAfter'])}
        for phase, report in reports.items()},
    'finalNativeGate': gate, 'inputsUnchanged': True,
    'scope': 'Original Forge lazyMap and queued Supplier contracts, loopback startup/save/reopen only.',
    'unverified': ['Unified comparison', 'Quilt tooltip/client/server contracts', 'C1 runtime', 'mixed-mod persistence', 'performance'],
    'networkObservation': 'No player accounts; loopback listener only. Vanilla Yggdrasil public-key request was refused; local control passed.'}
output = evidence / 'native-acceptance.json'
save_new(output, result)
print(json.dumps({'status': result['status'], 'liveJvms': gate['liveJvms'],
    'eligibleBytes': gate['eligibleBytes'], 'memoryEvents': gate['memoryEvents'],
    'acceptance': str(output), 'sha256': sha(output)}, indent=2))
