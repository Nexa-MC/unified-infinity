// SPDX-License-Identifier: MIT
package org.sinytra.connector.mod.compat;

import com.mojang.blaze3d.vertex.PoseStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.sinytra.connector.client.EmiRenderRoute;

/** Tests the real pose implementation without creating Minecraft or a graphics context. */
public final class EmiPoseRestoreTest {
    private static int checks;
    public static void main(String[] args) {
        PoseStack poses = new PoseStack();
        poses.translate(7, 11, 3);
        PoseStack.Pose baseline = poses.last();
        Matrix4f position = new Matrix4f(baseline.pose());
        Matrix3f normal = new Matrix3f(baseline.normal());
        Object screen = new Object(), graphics = new Object();
        EmiRenderRoute.begin(screen, graphics, NativeEmiRenderBridge.restoreOnFailure(poses));
        EmiRenderRoute.vanilla(screen, graphics);
        poses.pushPose(); poses.translate(100, 200, 0); poses.scale(2, 3, 4);
        poses.pushPose(); poses.translate(-33, 4, 9);
        RuntimeException primary = new RuntimeException("existing EMI render failed before pop");
        EmiRenderRoute.abort(screen, graphics, primary);
        check(poses.last() == baseline, "Extra poses from existing callback are removed");
        check(poses.last().pose().equals(position), "Original position matrix restored");
        check(poses.last().normal().equals(normal), "Original normal matrix restored");
        check(primary.getSuppressed().length == 0, "Valid callback unwind adds no suppressed failure");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Failure leaves no active invocation");
        check(poses.clear(), "Pose stack retains only its original root");
        // Nested render scope restores its own baseline and preserves the outer scope.
        EmiRenderRoute.begin(screen, graphics, NativeEmiRenderBridge.restoreOnFailure(poses));
        poses.pushPose(); PoseStack.Pose nested = poses.last();
        Object child = new Object();
        EmiRenderRoute.begin(child, graphics, NativeEmiRenderBridge.restoreOnFailure(poses));
        poses.pushPose(); poses.translate(1, 2, 3);
        EmiRenderRoute.abort(child, graphics, new RuntimeException("nested"));
        check(poses.last() == nested, "Nested failure restores nested entry pose");
        check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Nested failure retains outer invocation");
        poses.popPose(); EmiRenderRoute.end(screen, graphics);
        check(poses.last() == baseline, "Outer normal exit preserves baseline");
        // A renderer that popped below its entry state is diagnosed; primary error survives.
        poses.pushPose();
        EmiRenderRoute.begin(screen, graphics, NativeEmiRenderBridge.restoreOnFailure(poses));
        poses.popPose();
        RuntimeException invalid = new RuntimeException("broken renderer");
        EmiRenderRoute.abort(screen, graphics, invalid);
        check(invalid.getSuppressed().length == 1, "Underflow recorded on original error");
        check(poses.last() == baseline && poses.clear(), "Underflow guard does not pop the root");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Underflow still clears the invocation");
        System.out.println("PASS EmiPoseRestoreTest: " + checks + " checks");
    }
    private static void check(boolean condition, String label) { checks++; if (!condition) throw new AssertionError(label); }
}
