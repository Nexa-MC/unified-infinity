// SPDX-License-Identifier: MIT
package org.sinytra.connector.service;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;

/** Structural regression for the exact post-Mixin callback seam; no game bootstrap. */
public final class EmiRenderMarkerTest {
    private static final String MANAGER = "dev/emi/emi/screen/EmiScreenManager";
    private static final String ROUTE = "org/sinytra/connector/client/EmiRenderRoute";
    private static int checks;
    public static void main(String[] args) {
        ClassNode other = fixture(); other.name = "fixture/OtherScreen";
        check(!EmiRenderMarker.apply(other), "Unrelated class unchanged");
        check(markers(other) == 0, "No unrelated marker");
        ClassNode normal = fixture();
        int instructions = normal.methods.getFirst().instructions.size();
        check(EmiRenderMarker.apply(normal), "Exact callback marked");
        check(markers(normal) == 1, "Exactly one route marker");
        check(normal.methods.getFirst().instructions.size() == instructions + 3, "Only three stack-preserving instructions added");
        MethodInsnNode render = null;
        for (AbstractInsnNode insn : normal.methods.getFirst().instructions)
            if (insn instanceof MethodInsnNode call && call.owner.equals(MANAGER) && call.name.equals("render")) render = call;
        check(render.getPrevious() instanceof MethodInsnNode call && call.owner.equals(ROUTE) && call.name.equals("vanilla"), "Marker immediately precedes original callback");
        check(render.getPrevious().getPrevious().getPrevious() instanceof VarInsnNode load && load.var == 0 && load.getOpcode() == Opcodes.ALOAD, "Original screen identity passed without consuming callback arguments");
        check(render.getPrevious().getPrevious() instanceof VarInsnNode load && load.var == 1 && load.getOpcode() == Opcodes.ALOAD, "Original graphics identity passed");
        check(!EmiRenderMarker.apply(normal), "Second transformation is idempotent");
        check(markers(normal) == 1, "Reentry creates no duplicate marker");
        ClassNode absent = fixture(); absent.methods.clear(); rejects(absent, "Missing callback fails closed");
        ClassNode duplicate = fixture(); duplicate.methods.add(fixture().methods.getFirst()); rejects(duplicate, "Multiple callbacks fail closed");
        ClassNode wrongDescriptor = fixture(); wrongDescriptor.methods.getFirst().desc = "()V"; rejects(wrongDescriptor, "Unknown callback descriptor fails closed");
        ClassNode isStatic = fixture(); isStatic.methods.getFirst().access |= Opcodes.ACC_STATIC; rejects(isStatic, "Static callback cannot use screen this");
        ClassNode missingForeground = fixture();
        var insns = missingForeground.methods.getFirst().instructions;
        for (AbstractInsnNode insn : insns.toArray()) if (insn instanceof MethodInsnNode call && call.name.equals("drawForeground")) insns.remove(insn);
        rejects(missingForeground, "Changed foreground contract fails closed");
        ClassNode excessMarker = fixture(); var method = excessMarker.methods.getFirst();
        for (int i = 0; i < 2; i++) method.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, ROUTE, "vanilla", "(Ljava/lang/Object;Ljava/lang/Object;)V", false));
        rejects(excessMarker, "Duplicate preexisting markers fail closed");
        System.out.println("PASS EmiRenderMarkerTest: " + checks + " checks");
    }
    private static ClassNode fixture() {
        ClassNode node = new ClassNode(); node.name = "net/minecraft/client/gui/screens/inventory/AbstractContainerScreen";
        MethodNode callback = new MethodNode(Opcodes.ACC_PRIVATE, "handler$emi$renderForeground",
            "(Lnet/minecraft/client/gui/GuiGraphics;IIFLorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V", null, null);
        callback.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, MANAGER, "render", "(Ldev/emi/emi/runtime/EmiDrawContext;IIF)V", false));
        callback.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, MANAGER, "drawForeground", "(Ldev/emi/emi/runtime/EmiDrawContext;IIF)V", false));
        node.methods.add(callback); return node;
    }
    private static int markers(ClassNode node) {
        int n = 0; for (var method : node.methods) for (var insn : method.instructions)
            if (insn instanceof MethodInsnNode call && call.owner.equals(ROUTE)) n++;
        return n;
    }
    private static void rejects(ClassNode node, String label) {
        try { EmiRenderMarker.apply(node); throw new AssertionError(label); }
        catch (IllegalStateException expected) { check(true, label); }
    }
    private static void check(boolean condition, String label) { checks++; if (!condition) throw new AssertionError(label); }
}
