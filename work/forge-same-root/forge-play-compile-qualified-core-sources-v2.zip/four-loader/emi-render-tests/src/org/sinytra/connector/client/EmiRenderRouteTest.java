/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Mod Compatibility Runtime contributors
 */
package org.sinytra.connector.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Dependency-free contract main for the service-layer routing state machine.
 * These fixtures model callback order; they do not load Minecraft or prove the
 * host event adapter or bytecode marker integration. Prepared without a JVM run.
 */
public final class EmiRenderRouteTest {
    private static int checks;

    private EmiRenderRouteTest() {}

    public static void main(String[] args) throws InterruptedException {
        unscopedCallbacksDoNothing();
        ordinaryCallbackKeepsOwnership();
        fallbackCallbacksRunOnceInOrder();
        foregroundRequiresRenderClaim();
        cancelledPreClosesWithoutCallbacks();
        screenAndGraphicsUseIdentity();
        nestedVanillaAndFallbackRestoreTheirParents();
        nestedIdenticalTokensAreIndependent();
        nestedGraphicsContextsAreIndependent();
        markerRequiresCurrentGraphicsIdentity();
        markerCannotReachAnOuterFrame();
        mismatchedEndCannotPopAnOuterFrame();
        callbackFailuresCleanUpInFinally();
        nestedFailureRestoresParent();
        lateVanillaMarkerSuppressesFallbackForeground();
        invalidBeginDoesNotDisturbParent();
        threadsDoNotShareFrames();
        abortedCallbackRestoresCapturedMatrices();
        abortPreservesPrimaryAndSuppressesCleanupFailure();
        abortDoesNotSuppressPrimaryOntoItself();
        wrongContextAbortDoesNothing();
        nestedAbortRestoresParentAndMatrices();
        normalAndCancelledEndDoNotClean();
        reentrantAbortRunsCleanupOnce();
        abortWithoutCleanupClosesFrame();
        System.out.println("PASS EmiRenderRouteTest: " + checks + " checks");
    }

    private static void unscopedCallbacksDoNothing() {
        Object screen = new Object();
        Object graphics = new Object();
        EmiRenderRoute.vanilla(screen, graphics);
        EmiRenderRoute.end(screen, graphics);
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Unscoped render cannot claim");
        check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Unscoped foreground cannot claim");
        EmiRenderRoute.begin(screen, graphics);
        try {
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Unscoped marker does not poison next frame");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void ordinaryCallbackKeepsOwnership() {
        Fixture fixture = new Fixture();
        EmiRenderRoute.begin(fixture.screen, fixture.graphics);
        try {
            fixture.existingCallback();
            fixture.hostCallbacks();
            fixture.hostCallbacks();
            check(fixture.calls.equals(List.of("fabric-render", "fabric-foreground")),
                "Ordinary transplanted callback runs once and suppresses host callbacks");
            check(fixture.state == 2, "Original callback leaves the complete render state");
        } finally {
            EmiRenderRoute.end(fixture.screen, fixture.graphics);
        }
        check(!EmiRenderRoute.claimFallbackRender(fixture.screen, fixture.graphics), "Post closes original route");
    }

    private static void fallbackCallbacksRunOnceInOrder() {
        Fixture fixture = new Fixture();
        EmiRenderRoute.begin(fixture.screen, fixture.graphics);
        try {
            fixture.hostCallbacks();
            fixture.hostCallbacks();
            check(fixture.calls.equals(List.of("fallback-render", "fallback-foreground")),
                "Repeated host events invoke render then foreground exactly once");
            check(fixture.state == 2, "Fallback reaches the same complete render state");
        } finally {
            EmiRenderRoute.end(fixture.screen, fixture.graphics);
        }
        EmiRenderRoute.begin(fixture.screen, fixture.graphics);
        try {
            check(EmiRenderRoute.claimFallbackRender(fixture.screen, fixture.graphics),
                "A later invocation with the same tokens can render again");
        } finally {
            EmiRenderRoute.end(fixture.screen, fixture.graphics);
        }
    }

    private static void foregroundRequiresRenderClaim() {
        Object screen = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(screen, graphics);
        try {
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Foreground cannot initiate fallback");
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Repeated early foreground stays inert");
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Early foreground does not consume render");
            check(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Foreground follows render claim");
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Foreground can only be claimed once");
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Render stays consumed after foreground");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void cancelledPreClosesWithoutCallbacks() {
        Object screen = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(screen, graphics);
        try {
            // A canceled native Pre skips the screen render and container events.
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Canceled Pre has no render ownership");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
        check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Canceled Post removes its frame");
        EmiRenderRoute.begin(screen, graphics);
        try {
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Cancellation does not poison later render");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void screenAndGraphicsUseIdentity() {
        Object screen = new EqualToken();
        Object otherScreen = new EqualToken();
        Object graphics = new EqualToken();
        Object otherGraphics = new EqualToken();
        check(screen.equals(otherScreen) && graphics.equals(otherGraphics), "Negative tokens compare equal by value");
        EmiRenderRoute.begin(screen, graphics);
        try {
            EmiRenderRoute.vanilla(otherScreen, graphics);
            EmiRenderRoute.vanilla(screen, otherGraphics);
            EmiRenderRoute.end(otherScreen, graphics);
            EmiRenderRoute.end(screen, otherGraphics);
            check(!EmiRenderRoute.claimFallbackRender(otherScreen, graphics), "Equal but distinct screen cannot claim");
            check(!EmiRenderRoute.claimFallbackRender(screen, otherGraphics), "Equal but distinct graphics cannot claim");
            check(!EmiRenderRoute.claimFallbackRender(null, graphics), "Null screen cannot claim");
            check(!EmiRenderRoute.claimFallbackRender(screen, null), "Null graphics cannot claim");
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Mismatched markers and ends preserve current frame");
            check(!EmiRenderRoute.claimFallbackForeground(otherScreen, graphics), "Foreground requires exact screen");
            check(!EmiRenderRoute.claimFallbackForeground(screen, otherGraphics), "Foreground requires exact graphics");
            check(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Wrong foreground attempts do not consume claim");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void nestedVanillaAndFallbackRestoreTheirParents() {
        Object outer = new Object();
        Object inner = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(outer, graphics);
        try {
            EmiRenderRoute.vanilla(outer, graphics);
            EmiRenderRoute.begin(inner, graphics);
            try {
                check(EmiRenderRoute.claimFallbackRender(inner, graphics), "Nested screen is not suppressed by outer marker");
                check(EmiRenderRoute.claimFallbackForeground(inner, graphics), "Nested fallback can complete");
            } finally {
                EmiRenderRoute.end(inner, graphics);
            }
            check(!EmiRenderRoute.claimFallbackRender(outer, graphics), "Outer marker is restored after nested fallback");
            check(!EmiRenderRoute.claimFallbackForeground(outer, graphics), "Outer original route has no fallback foreground");
        } finally {
            EmiRenderRoute.end(outer, graphics);
        }
        EmiRenderRoute.begin(outer, graphics);
        try {
            check(EmiRenderRoute.claimFallbackRender(outer, graphics), "Outer fallback claims render");
            EmiRenderRoute.begin(inner, graphics);
            try {
                EmiRenderRoute.vanilla(inner, graphics);
                check(!EmiRenderRoute.claimFallbackRender(inner, graphics), "Inner original route suppresses its fallback");
            } finally {
                EmiRenderRoute.end(inner, graphics);
            }
            check(!EmiRenderRoute.claimFallbackRender(outer, graphics), "Outer render claim survives nested original route");
            check(EmiRenderRoute.claimFallbackForeground(outer, graphics), "Outer foreground remains eligible");
        } finally {
            EmiRenderRoute.end(outer, graphics);
        }
    }

    private static void nestedIdenticalTokensAreIndependent() {
        Object screen = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(screen, graphics);
        try {
            EmiRenderRoute.vanilla(screen, graphics);
            EmiRenderRoute.begin(screen, graphics);
            try {
                check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Reentrant identical tokens create a fresh invocation");
                check(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Reentrant identical tokens have independent foreground");
            } finally {
                EmiRenderRoute.end(screen, graphics);
            }
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Same-token child end restores marked parent");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
        check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Both same-token frames were removed");
    }

    private static void nestedGraphicsContextsAreIndependent() {
        Object screen = new Object();
        Object outerGraphics = new Object();
        Object innerGraphics = new Object();
        EmiRenderRoute.begin(screen, outerGraphics);
        try {
            EmiRenderRoute.begin(screen, innerGraphics);
            try {
                EmiRenderRoute.vanilla(screen, innerGraphics);
                check(!EmiRenderRoute.claimFallbackRender(screen, innerGraphics), "Marker owns current graphics context");
                check(!EmiRenderRoute.claimFallbackRender(screen, outerGraphics), "Outer context cannot claim while child is active");
            } finally {
                EmiRenderRoute.end(screen, innerGraphics);
            }
            check(EmiRenderRoute.claimFallbackRender(screen, outerGraphics), "Inner marker does not suppress outer graphics context");
        } finally {
            EmiRenderRoute.end(screen, outerGraphics);
        }
    }

    private static void markerRequiresCurrentGraphicsIdentity() {
        Object screen = new Object();
        Object graphics = new Object();
        Object otherGraphics = new Object();
        EmiRenderRoute.begin(screen, graphics);
        try {
            EmiRenderRoute.vanilla(screen, otherGraphics);
            check(EmiRenderRoute.claimFallbackRender(screen, graphics),
                "Same-screen marker with another graphics object does not suppress active fallback");
            check(EmiRenderRoute.claimFallbackForeground(screen, graphics),
                "Wrong-context marker does not suppress active fallback foreground");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void markerCannotReachAnOuterFrame() {
        Object outer = new Object();
        Object inner = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(outer, graphics);
        try {
            EmiRenderRoute.begin(inner, graphics);
            try {
                EmiRenderRoute.vanilla(outer, graphics);
                check(EmiRenderRoute.claimFallbackRender(inner, graphics), "Wrong-screen marker does not own inner frame");
            } finally {
                EmiRenderRoute.end(inner, graphics);
            }
            check(EmiRenderRoute.claimFallbackRender(outer, graphics), "Marker does not search down the stack");
        } finally {
            EmiRenderRoute.end(outer, graphics);
        }
    }

    private static void mismatchedEndCannotPopAnOuterFrame() {
        Object outer = new Object();
        Object inner = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(outer, graphics);
        try {
            EmiRenderRoute.begin(inner, graphics);
            try {
                EmiRenderRoute.end(outer, graphics);
                check(EmiRenderRoute.claimFallbackRender(inner, graphics), "Out-of-order end cannot pop current child");
            } finally {
                EmiRenderRoute.end(inner, graphics);
            }
            EmiRenderRoute.end(inner, graphics);
            check(EmiRenderRoute.claimFallbackRender(outer, graphics), "Repeated child end cannot pop distinct parent");
        } finally {
            EmiRenderRoute.end(outer, graphics);
        }
    }

    private static void callbackFailuresCleanUpInFinally() {
        for (int phase = 0; phase < 3; phase++) {
            Object screen = new Object();
            Object graphics = new Object();
            RuntimeException failure = new RuntimeException("fixture phase " + phase);
            try {
                EmiRenderRoute.begin(screen, graphics);
                try {
                    if (phase == 0) {
                        EmiRenderRoute.vanilla(screen, graphics);
                    } else {
                        check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Failing fallback acquired render");
                        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Claim precedes callback, preventing render retry");
                        if (phase == 2) {
                            check(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Failing foreground acquired ownership");
                            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Claim precedes callback, preventing foreground retry");
                        }
                    }
                    throw failure;
                } finally {
                    EmiRenderRoute.end(screen, graphics);
                }
            } catch (RuntimeException actual) {
                check(actual == failure, "Cleanup preserves callback failure identity");
            }
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Failed invocation leaves no active render");
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Failed invocation leaves no active foreground");
            EmiRenderRoute.begin(screen, graphics);
            try {
                check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Next invocation recovers after callback failure");
            } finally {
                EmiRenderRoute.end(screen, graphics);
            }
        }
    }

    private static void nestedFailureRestoresParent() {
        Object outer = new Object();
        Object inner = new Object();
        Object graphics = new Object();
        RuntimeException failure = new RuntimeException("nested callback");
        EmiRenderRoute.begin(outer, graphics);
        try {
            check(EmiRenderRoute.claimFallbackRender(outer, graphics), "Outer render claimed before reentrant callback");
            try {
                EmiRenderRoute.begin(inner, graphics);
                try {
                    check(EmiRenderRoute.claimFallbackRender(inner, graphics), "Inner render claimed before failure");
                    throw failure;
                } finally {
                    EmiRenderRoute.end(inner, graphics);
                }
            } catch (RuntimeException actual) {
                check(actual == failure, "Nested cleanup preserves original failure");
            }
            check(!EmiRenderRoute.claimFallbackRender(outer, graphics), "Nested failure preserves consumed outer render");
            check(EmiRenderRoute.claimFallbackForeground(outer, graphics), "Nested failure restores pending outer foreground");
        } finally {
            EmiRenderRoute.end(outer, graphics);
        }
    }

    private static void lateVanillaMarkerSuppressesFallbackForeground() {
        Object screen = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(screen, graphics);
        try {
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Fallback can claim before unexpected late marker");
            EmiRenderRoute.vanilla(screen, graphics);
            EmiRenderRoute.vanilla(screen, graphics);
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Repeated marker never reopens render");
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Late original callback suppresses duplicate foreground");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void invalidBeginDoesNotDisturbParent() {
        Object screen = new Object();
        Object graphics = new Object();
        EmiRenderRoute.begin(screen, graphics);
        try {
            expectNullBegin(null, graphics);
            expectNullBegin(screen, null);
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Rejected begin leaves parent current");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void expectNullBegin(Object screen, Object graphics) {
        try {
            EmiRenderRoute.begin(screen, graphics);
            throw new AssertionError("Null identity token must be rejected");
        } catch (NullPointerException expected) {
            check(true, "Null begin rejected before frame mutation");
        }
    }

    private static void threadsDoNotShareFrames() throws InterruptedException {
        Object screen = new Object();
        Object graphics = new Object();
        Throwable[] failure = new Throwable[1];
        EmiRenderRoute.begin(screen, graphics);
        try {
            EmiRenderRoute.vanilla(screen, graphics);
            Thread other = new Thread(() -> {
                try {
                    require(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Other thread starts unscoped");
                    EmiRenderRoute.begin(screen, graphics);
                    try {
                        require(EmiRenderRoute.claimFallbackRender(screen, graphics), "Other thread ignores parent-thread marker");
                        require(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Other thread owns its foreground");
                    } finally {
                        EmiRenderRoute.end(screen, graphics);
                    }
                    require(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Other thread removes its frame");
                } catch (Throwable actual) {
                    failure[0] = actual;
                }
            }, "emi-render-route-contract");
            other.start();
            other.join();
            if (failure[0] != null) {
                throw new AssertionError("Independent thread failed", failure[0]);
            }
            checks += 4;
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Other thread cannot alter original ownership");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
    }

    private static void check(boolean condition, String message) {
        require(condition, message);
        checks++;
    }

    private static void abortedCallbackRestoresCapturedMatrices() {
        Object screen = new Object();
        ModelGraphics graphics = new ModelGraphics();
        ModelPose original = graphics.current();
        int[] pose = original.pose.clone();
        int[] normal = original.normal.clone();
        RuntimeException primary = new RuntimeException("original EMI render failed");
        try {
            hostRender(screen, graphics, graphics.captureFailureCleanup(), () -> {
                EmiRenderRoute.vanilla(screen, graphics);
                graphics.mutate();
                graphics.push();
                graphics.mutate();
                graphics.push();
                graphics.mutate();
                throw primary;
            });
            throw new AssertionError("Expected original render failure");
        } catch (RuntimeException actual) {
            check(actual == primary, "Existing callback failure remains the primary throwable");
        }
        check(graphics.cleanupCalls == 1, "Original callback failure invokes cleanup exactly once");
        check(graphics.depth() == 1 && graphics.current() == original, "Cleanup pops extra poses to the original baseline");
        check(Arrays.equals(graphics.current().pose, pose), "Cleanup restores copied position matrix contents");
        check(Arrays.equals(graphics.current().normal, normal), "Cleanup restores copied normal matrix contents");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Original callback abort closes the marked frame");
        EmiRenderRoute.abort(screen, graphics, primary);
        check(graphics.cleanupCalls == 1, "Repeated unscoped abort does not repeat cleanup");
    }

    private static void abortPreservesPrimaryAndSuppressesCleanupFailure() {
        Object screen = new Object();
        Object graphics = new Object();
        AssertionError primary = new AssertionError("render error");
        AssertionError cleanupFailure = new AssertionError("cleanup error");
        int[] calls = {0};
        try {
            hostRender(screen, graphics, () -> {
                calls[0]++;
                throw cleanupFailure;
            }, () -> {
                check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Failing render owns fallback before abort");
                throw primary;
            });
            throw new AssertionError("Expected primary render error");
        } catch (AssertionError actual) {
            check(actual == primary, "Cleanup Error does not replace the primary Error");
        }
        check(calls[0] == 1, "Failing cleanup is attempted exactly once");
        check(primary.getSuppressed().length == 1 && primary.getSuppressed()[0] == cleanupFailure,
            "Cleanup failure is retained as a suppressed exception on primary");
        check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Cleanup failure still removes frame");
        EmiRenderRoute.abort(screen, graphics, primary);
        check(calls[0] == 1 && primary.getSuppressed().length == 1, "Repeated abort cannot append the same cleanup again");
    }

    private static void abortDoesNotSuppressPrimaryOntoItself() {
        Object screen = new Object();
        Object graphics = new Object();
        RuntimeException primary = new RuntimeException("shared failure instance");
        try {
            hostRender(screen, graphics, () -> { throw primary; }, () -> { throw primary; });
            throw new AssertionError("Expected primary failure");
        } catch (RuntimeException actual) {
            check(actual == primary, "Cleanup throwing primary itself does not trigger self-suppression failure");
        }
        check(primary.getSuppressed().length == 0, "Primary is never suppressed onto itself");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Self-suppression guard still closes frame");
    }

    private static void wrongContextAbortDoesNothing() {
        Object screen = new EqualToken();
        Object graphics = new EqualToken();
        RuntimeException primary = new RuntimeException("wrong context");
        int[] calls = {0};
        EmiRenderRoute.begin(screen, graphics, () -> calls[0]++);
        try {
            EmiRenderRoute.abort(new EqualToken(), graphics, primary);
            EmiRenderRoute.abort(screen, new EqualToken(), primary);
            check(calls[0] == 0, "Wrong identity abort does not invoke cleanup");
            check(primary.getSuppressed().length == 0, "Wrong identity abort does not alter primary");
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Wrong identity abort leaves frame active");
        } finally {
            EmiRenderRoute.end(screen, graphics);
        }
        check(calls[0] == 0, "Normal end after ignored abort still skips cleanup");
    }

    private static void nestedAbortRestoresParentAndMatrices() {
        Object screen = new Object();
        ModelGraphics graphics = new ModelGraphics();
        int[] originalPose = graphics.current().pose.clone();
        int[] originalNormal = graphics.current().normal.clone();
        RuntimeException innerFailure = new RuntimeException("nested callback");
        RuntimeException outerFailure = new RuntimeException("outer callback");
        EmiRenderRoute.begin(screen, graphics, graphics.captureFailureCleanup());
        try {
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Outer frame owns render before nested failure");
            graphics.mutate();
            graphics.push();
            graphics.mutate();
            ModelPose innerBaseline = graphics.current();
            int[] innerPose = innerBaseline.pose.clone();
            int[] innerNormal = innerBaseline.normal.clone();
            try {
                hostRender(screen, graphics, graphics.captureFailureCleanup(), () -> {
                    EmiRenderRoute.vanilla(screen, graphics);
                    graphics.mutate();
                    graphics.push();
                    graphics.mutate();
                    throw innerFailure;
                });
                throw new AssertionError("Expected nested failure");
            } catch (RuntimeException actual) {
                check(actual == innerFailure, "Nested identical-token abort preserves primary");
            }
            check(graphics.cleanupCalls == 1 && graphics.depth() == 2 && graphics.current() == innerBaseline,
                "Nested abort restores only its captured pose baseline");
            check(Arrays.equals(graphics.current().pose, innerPose) && Arrays.equals(graphics.current().normal, innerNormal),
                "Nested abort restores both matrices without overwriting outer state");
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Nested abort restores consumed outer render claim");
            check(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Nested abort restores eligible outer foreground");
        } finally {
            EmiRenderRoute.abort(screen, graphics, outerFailure);
        }
        check(graphics.cleanupCalls == 2 && graphics.depth() == 1, "Each failed nested frame runs its own cleanup once");
        check(Arrays.equals(graphics.current().pose, originalPose) && Arrays.equals(graphics.current().normal, originalNormal),
            "Outer abort restores the original matrix baseline");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Outer abort removes the final frame");
    }

    private static void normalAndCancelledEndDoNotClean() {
        Object screen = new Object();
        Object graphics = new Object();
        int[] calls = {0};
        Runnable cleanup = () -> calls[0]++;
        hostRender(screen, graphics, cleanup, () -> EmiRenderRoute.vanilla(screen, graphics));
        check(calls[0] == 0, "Ordinary original callback return does not run failure cleanup");
        hostRender(screen, graphics, cleanup, () -> {
            check(EmiRenderRoute.claimFallbackRender(screen, graphics), "Normal fallback owns render");
            check(EmiRenderRoute.claimFallbackForeground(screen, graphics), "Normal fallback owns foreground");
        });
        check(calls[0] == 0, "Normal fallback return does not run failure cleanup");
        hostRender(screen, graphics, cleanup, () -> {
            // Canceled Pre returns normally without invoking screen callbacks.
            check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Canceled invocation has no fallback foreground");
        });
        check(calls[0] == 0, "Canceled Pre return does not run failure cleanup");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Canceled normal return removes its frame");
    }

    private static void reentrantAbortRunsCleanupOnce() {
        Object screen = new Object();
        Object graphics = new Object();
        RuntimeException primary = new RuntimeException("reentrant cleanup");
        int[] calls = {0};
        EmiRenderRoute.begin(screen, graphics, () -> {
            calls[0]++;
            EmiRenderRoute.abort(screen, graphics, primary);
        });
        EmiRenderRoute.abort(screen, graphics, primary);
        check(calls[0] == 1, "Cleanup ownership is claimed before a reentrant abort");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Reentrant abort leaves no frame");
    }

    private static void abortWithoutCleanupClosesFrame() {
        Object screen = new Object();
        Object graphics = new Object();
        RuntimeException primary = new RuntimeException("no cleanup");
        EmiRenderRoute.begin(screen, graphics);
        EmiRenderRoute.abort(screen, graphics, primary);
        check(primary.getSuppressed().length == 0, "Two-argument begin abort does not invent cleanup failure");
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Two-argument begin can be aborted");
        EmiRenderRoute.begin(screen, graphics, null);
        EmiRenderRoute.abort(screen, graphics, primary);
        check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "Explicit null cleanup can be aborted");
    }

    /** Mirrors the host wrapper's normal-return and catch/rethrow boundaries. */
    private static void hostRender(Object screen, Object graphics, Runnable cleanup, Runnable render) {
        EmiRenderRoute.begin(screen, graphics, cleanup);
        try {
            render.run();
        } catch (Throwable primary) {
            EmiRenderRoute.abort(screen, graphics, primary);
            throw primary;
        }
        EmiRenderRoute.end(screen, graphics);
    }

    /** Copies real-sized matrix arrays without depending on game or math types. */
    private static final class ModelGraphics {
        private final List<ModelPose> poses = new ArrayList<>();
        private int cleanupCalls;

        private ModelGraphics() {
            poses.add(new ModelPose(new int[16], new int[9]));
            mutate();
        }

        private ModelPose current() {
            return poses.get(poses.size() - 1);
        }

        private int depth() {
            return poses.size();
        }

        private void push() {
            poses.add(new ModelPose(current().pose.clone(), current().normal.clone()));
        }

        private void mutate() {
            for (int i = 0; i < current().pose.length; i++) current().pose[i] += i + 1;
            for (int i = 0; i < current().normal.length; i++) current().normal[i] += 2 * i + 1;
        }

        private Runnable captureFailureCleanup() {
            int originalDepth = depth();
            ModelPose original = current();
            int[] pose = original.pose.clone();
            int[] normal = original.normal.clone();
            return () -> {
                cleanupCalls++;
                while (depth() > originalDepth) poses.remove(poses.size() - 1);
                require(depth() == originalDepth && current() == original, "Cleanup reaches the captured matrix baseline");
                System.arraycopy(pose, 0, original.pose, 0, pose.length);
                System.arraycopy(normal, 0, original.normal, 0, normal.length);
            };
        }
    }

    private static final class ModelPose {
        private final int[] pose;
        private final int[] normal;

        private ModelPose(int[] pose, int[] normal) {
            this.pose = pose;
            this.normal = normal;
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static final class Fixture {
        private final Object screen = new Object();
        private final Object graphics = new Object();
        private final List<String> calls = new ArrayList<>();
        private int state;

        private void existingCallback() {
            EmiRenderRoute.vanilla(screen, graphics);
            render("fabric-render");
            foreground("fabric-foreground");
        }

        private void hostCallbacks() {
            if (EmiRenderRoute.claimFallbackRender(screen, graphics)) {
                render("fallback-render");
            }
            if (EmiRenderRoute.claimFallbackForeground(screen, graphics)) {
                foreground("fallback-foreground");
            }
        }

        private void render(String label) {
            check(state == 0, "Render callback starts from untouched state");
            calls.add(label);
            state = 1;
        }

        private void foreground(String label) {
            check(state == 1, "Foreground callback observes completed render callback");
            calls.add(label);
            state = 2;
        }
    }

    private static final class EqualToken {
        @Override
        public boolean equals(Object other) {
            return other instanceof EqualToken;
        }

        @Override
        public int hashCode() {
            return 1;
        }
    }
}
