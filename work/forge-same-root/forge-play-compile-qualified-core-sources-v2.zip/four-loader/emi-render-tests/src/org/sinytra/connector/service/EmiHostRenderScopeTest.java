// SPDX-License-Identifier: MIT
package org.sinytra.connector.service;

import java.lang.reflect.InvocationTargetException;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.sinytra.connector.client.EmiRenderRoute;

/** Executes the emitted wrapper with isolated generated stubs, never Minecraft bootstrap. */
public final class EmiHostRenderScopeTest {
    private static final String HOST = EmiHostRenderScope.HOST;
    private static final String SCREEN = "net/minecraft/client/gui/screens/Screen";
    private static final String GRAPHICS = "net/minecraft/client/gui/GuiGraphics";
    private static final String BRIDGE = "org/sinytra/connector/mod/compat/NativeEmiRenderBridge";
    private static final String SELF = "org/sinytra/connector/service/EmiHostRenderScopeTest";
    private static final String DESC = "(L"+SCREEN+";L"+GRAPHICS+";IIF)V";
    private static final List<String> events = new ArrayList<>();
    private static String mode;
    private static int pose, checks;
    private static RuntimeException failure;

    public static void main(String[] args) throws Exception {
        ClassNode node = fixture();
        MethodNode original = node.methods.stream().filter(m -> m.name.equals("drawScreenInternal")).findFirst().orElseThrow();
        InsnList originalBody = original.instructions;
        check(EmiHostRenderScope.apply(node), "Host wrapper added");
        check(original.instructions == originalBody, "Original host body retained");
        check(!EmiHostRenderScope.apply(node), "Repeated transform is idempotent");
        ClassNode unrelated = fixture(); unrelated.name = "fixture/Other";
        check(!EmiHostRenderScope.apply(unrelated), "Unrelated host untouched");
        ClassNode absent = fixture(); absent.methods.removeIf(m -> m.name.equals("drawScreenInternal")); rejects(absent);
        ClassNode changed = fixture(); changed.methods.stream().filter(m -> m.name.equals("drawScreenInternal")).findFirst().orElseThrow().access = Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC; rejects(changed);
        Map<String,byte[]> definitions = new HashMap<>();
        definitions.put(SCREEN, bytes(simple(SCREEN))); definitions.put(GRAPHICS, bytes(simple(GRAPHICS)));
        definitions.put(HOST, bytes(node)); definitions.put(BRIDGE, bytes(bridge()));
        ClassLoader loader = new ClassLoader(EmiHostRenderScopeTest.class.getClassLoader()) {
            @Override protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
                synchronized (getClassLoadingLock(name)) {
                    byte[] data = definitions.get(name.replace('.', '/'));
                    if (data == null) return super.loadClass(name, resolve);
                    Class<?> type = findLoadedClass(name);
                    if (type == null) type = defineClass(name, data, 0, data.length);
                    if (resolve) resolveClass(type);
                    return type;
                }
            }
        };
        Class<?> s = loader.loadClass(SCREEN.replace('/','.')), g = loader.loadClass(GRAPHICS.replace('/','.'));
        Object screen = s.getConstructor().newInstance(), graphics = g.getConstructor().newInstance();
        var dispatch = loader.loadClass(HOST.replace('/','.')).getMethod("dispatch", s, g, int.class, int.class, float.class);
        for (String test : List.of("ordinary", "fallback", "canceled", "existing-throw", "fallback-throw", "pre-throw", "post-throw")) {
            mode = test; events.clear(); pose = 3; failure = new RuntimeException(test);
            try {
                dispatch.invoke(null, screen, graphics, 9, 11, 0.25f);
                check(!test.endsWith("throw"), "Only successful host invocations return normally");
            } catch (InvocationTargetException caught) {
                check(test.endsWith("throw") && caught.getCause() == failure, "Exact original failure survives emitted wrapper: " + test);
            }
            check(pose == 3, "Pose restored: " + test);
            check(!EmiRenderRoute.claimFallbackRender(screen, graphics), "No leaked frame: " + test);
            check(events.stream().filter(e -> e.equals("render")).count() <= 1, "At most one fallback render: " + test);
            check(events.stream().filter(e -> e.equals("foreground")).count() <= 1, "At most one fallback foreground: " + test);
            if (test.equals("ordinary") || test.equals("canceled")) check(!events.contains("render") && !events.contains("foreground"), "Ordinary/canceled screen adds no fallback");
            if (test.equals("fallback")) check(events.equals(List.of("begin", "render", "foreground")), "Fallback callback order is exact");
            if (test.endsWith("throw")) check(events.getLast().equals("cleanup"), "Exceptional host exit runs cleanup");
        }
        Object outer = new Object(), outerGraphics = new Object();
        EmiRenderRoute.begin(outer, outerGraphics); mode = "existing-throw"; events.clear(); pose = 3; failure = new RuntimeException("nested");
        try { dispatch.invoke(null, screen, graphics, 0, 0, 0f); throw new AssertionError("Expected nested failure"); }
        catch (InvocationTargetException expected) { check(expected.getCause() == failure, "Nested original failure retained"); }
        check(EmiRenderRoute.claimFallbackRender(outer, outerGraphics), "Nested wrapper failure restores outer invocation");
        EmiRenderRoute.end(outer, outerGraphics);
        System.out.println("PASS EmiHostRenderScopeTest: " + checks + " checks");
    }
    public static void begin(Object screen, Object graphics) {
        events.add("begin"); int baseline = pose;
        EmiRenderRoute.begin(screen, graphics, () -> { pose = baseline; events.add("cleanup"); });
    }
    public static void body(Object screen, Object graphics) {
        if (mode.equals("pre-throw")) { pose++; throw failure; }
        if (mode.equals("canceled")) { check(!EmiRenderRoute.claimFallbackForeground(screen, graphics), "Canceled Pre cannot draw during Post"); return; }
        if (mode.equals("ordinary") || mode.equals("existing-throw")) {
            EmiRenderRoute.vanilla(screen, graphics);
            if (mode.endsWith("throw")) { pose++; throw failure; }
        }
        if (EmiRenderRoute.claimFallbackRender(screen, graphics)) events.add("render");
        if (mode.equals("fallback-throw")) { pose++; throw failure; }
        if (EmiRenderRoute.claimFallbackForeground(screen, graphics)) events.add("foreground");
        if (mode.equals("post-throw")) { pose++; throw failure; }
    }
    private static ClassNode fixture() {
        ClassNode node = simple(HOST);
        MethodNode original = new MethodNode(Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC, "drawScreenInternal", DESC, null, null);
        original.instructions.add(new VarInsnNode(Opcodes.ALOAD,0)); original.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));
        original.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, SELF, "body", "(Ljava/lang/Object;Ljava/lang/Object;)V",false)); original.instructions.add(new InsnNode(Opcodes.RETURN)); original.maxLocals=5; original.maxStack=2; node.methods.add(original);
        MethodNode dispatch = new MethodNode(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC,"dispatch",DESC,null,null);
        dispatch.instructions.add(new VarInsnNode(Opcodes.ALOAD,0)); dispatch.instructions.add(new VarInsnNode(Opcodes.ALOAD,1)); dispatch.instructions.add(new VarInsnNode(Opcodes.ILOAD,2)); dispatch.instructions.add(new VarInsnNode(Opcodes.ILOAD,3)); dispatch.instructions.add(new VarInsnNode(Opcodes.FLOAD,4)); dispatch.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,HOST,"drawScreenInternal",DESC,false)); dispatch.instructions.add(new InsnNode(Opcodes.RETURN)); dispatch.maxStack=5; dispatch.maxLocals=5; node.methods.add(dispatch); return node;
    }
    private static ClassNode bridge() {
        ClassNode node=simple(BRIDGE); MethodNode begin=new MethodNode(Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC,"beginFrame","(Ljava/lang/Object;Ljava/lang/Object;)V",null,null);
        begin.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));begin.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));begin.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,SELF,"begin",begin.desc,false));begin.instructions.add(new InsnNode(Opcodes.RETURN));begin.maxLocals=2;begin.maxStack=2;node.methods.add(begin);return node;
    }
    private static ClassNode simple(String name) {
        ClassNode node=new ClassNode();node.version=Opcodes.V21;node.access=Opcodes.ACC_PUBLIC;node.name=name;node.superName="java/lang/Object";
        MethodNode init=new MethodNode(Opcodes.ACC_PUBLIC,"<init>","()V",null,null);init.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));init.instructions.add(new MethodInsnNode(Opcodes.INVOKESPECIAL,"java/lang/Object","<init>","()V",false));init.instructions.add(new InsnNode(Opcodes.RETURN));init.maxLocals=1;init.maxStack=1;node.methods.add(init);return node;
    }
    private static byte[] bytes(ClassNode node) { ClassWriter writer=new ClassWriter(0);node.accept(writer);return writer.toByteArray(); }
    private static void rejects(ClassNode node) { try { EmiHostRenderScope.apply(node);throw new AssertionError("Unknown host contract accepted"); } catch(IllegalStateException expected){check(true,"Unknown host contract rejected");} }
    private static void check(boolean condition,String label){checks++;if(!condition)throw new AssertionError(label);}
}
