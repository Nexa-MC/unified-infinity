// SPDX-License-Identifier: MIT
package org.sinytra.connector.locator;

import java.io.InputStream;
import java.lang.annotation.ElementType;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipFile;

import net.fabricmc.loader.api.EntrypointException;
import net.fabricmc.loader.api.LanguageAdapter;
import net.fabricmc.loader.api.LanguageAdapterException;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
import net.fabricmc.loader.impl.ModContainerImpl;
import net.fabricmc.loader.impl.discovery.BuiltinMetadataWrapper;
import net.fabricmc.loader.impl.entrypoint.EntrypointStorage;
import net.fabricmc.loader.impl.metadata.BuiltinModMetadata;
import net.fabricmc.loader.impl.metadata.EntrypointMetadata;
import net.neoforged.fml.loading.modscan.ModClassVisitor;
import net.neoforged.neoforgespi.language.IModFileInfo;
import net.neoforged.neoforgespi.language.IModInfo;
import net.neoforged.neoforgespi.language.ModFileScanData;
import net.neoforged.neoforgespi.locating.IModFile;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

/**
 * Standalone regression main. This source was prepared without running a JVM.
 * Arguments are the exact original Sophisticated Core and Backpacks JAR paths.
 * The original mod classes are read with ASM and are never loaded or initialized.
 */
public final class NativeEmiEntrypointsTest {
    private static final String MARKER = "Ldev/emi/emi/api/EmiEntrypoint;";
    private static final String CORE_CLASS =
        "net.p3pp3rf1y.sophisticatedcore.compat.recipeviewers.emi.CoreEmiPlugin";
    private static final String BACKPACK_CLASS =
        "net.p3pp3rf1y.sophisticatedbackpacks.compat.recipeviewers.emi.BackpackEmiPlugin";
    private static int checks;
    private static int nativeInitializations;
    private static int nativeConstructions;
    private static int wrongContractInitializations;
    private static int wrongContractConstructions;
    private static int privateConstructorInitializations;
    private static int privateConstructorConstructions;

    private NativeEmiEntrypointsTest() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("Expected Core JAR and Backpacks JAR paths");
        Path core = Path.of(args[0]).toAbsolutePath().normalize();
        Path backpacks = Path.of(args[1]).toAbsolutePath().normalize();
        exactOriginal(core, "acafbe72eb161b0b763feb61eba06584e97e48f563de75f767611ee520dfcad7", CORE_CLASS);
        exactOriginal(backpacks, "889fb2af58e9f7951d0553033a856078b28fcdf802ca13eb432336b2b7b9780c", BACKPACK_CLASS);
        annotationFiltering();
        lazyStorageAndAttribution(core);
        deferredFailureAttribution(core);
        nativeAdapterBehavior(core);
        System.out.println("PASS NativeEmiEntrypointsTest: " + checks + " checks");
    }

    private static void exactOriginal(Path jar, String expectedHash, String className) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = Files.newInputStream(jar)) {
            byte[] buffer = new byte[8192];
            for (int read; (read = input.read(buffer)) != -1;) digest.update(buffer, 0, read);
        }
        check(HexFormat.of().formatHex(digest.digest()).equals(expectedHash), "Original input digest: " + jar);
        byte[] bytes;
        try (ZipFile archive = new ZipFile(jar.toFile())) {
            var entry = archive.getEntry(className.replace('.', '/') + ".class");
            check(entry != null, "Original plugin class is present: " + className);
            try (InputStream input = archive.getInputStream(entry)) { bytes = input.readAllBytes(); }
        }
        AtomicInteger invisible = new AtomicInteger();
        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                if (descriptor.equals(MARKER)) {
                    check(!visible, "Original marker is runtime-invisible: " + className);
                    invisible.incrementAndGet();
                }
                return null;
            }
        }, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        check(invisible.get() == 1, "Exactly one original TYPE marker: " + className);
        ModFileScanData scan = new ModFileScanData();
        scan(bytes, scan);
        check(NativeEmiEntrypoints.annotatedClasses(scan).equals(List.of(className)),
            "Real FML scanner discovers original plugin without loading it: " + className);
    }

    private static void annotationFiltering() {
        ModFileScanData scan = new ModFileScanData();
        check(NativeEmiEntrypoints.annotatedClasses(scan).isEmpty(), "Empty scan has no plugins");
        scan(fixtureClass("fixture/Unrelated", "Lfixture/UnrelatedMarker;", false, false), scan);
        scan(fixtureClass("fixture/MethodOnly", null, false, true), scan);
        check(scan.getAnnotations().stream().anyMatch(a -> a.targetType() == ElementType.METHOD
                && a.annotationType().equals(Type.getType(MARKER))), "Negative method marker reached real scanner");
        check(NativeEmiEntrypoints.annotatedClasses(scan).isEmpty(),
            "Unrelated invisible and EMI method annotations are excluded");
        scan(fixtureClass("fixture/ZPlugin", MARKER, false, false), scan);
        scan(fixtureClass("fixture/APlugin", MARKER, true, false), scan);
        scan.getAnnotations().add(new ModFileScanData.AnnotationData(Type.getType(MARKER), ElementType.TYPE,
            Type.getObjectType("fixture/APlugin"), "fixture.APlugin", Map.of("duplicate", true)));
        check(NativeEmiEntrypoints.annotatedClasses(scan).equals(List.of("fixture.APlugin", "fixture.ZPlugin")),
            "TYPE plugins are sorted and distinct across annotation visibility");
        scan.getAnnotations().add(new ModFileScanData.AnnotationData(Type.getType(MARKER), ElementType.TYPE,
            Type.getObjectType("fixture/ActualClass"), "fixture.OtherClass", Map.of()));
        try {
            NativeEmiEntrypoints.annotatedClasses(scan);
            throw new AssertionError("Expected invalid TYPE owner to fail closed");
        } catch (IllegalStateException expected) {
            check(expected.getMessage().contains("owner"), "Mismatched class/member identity fails with owner diagnostic");
        }
    }

    private static byte[] fixtureClass(String internalName, String marker, boolean visible, boolean methodMarker) {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V17, Opcodes.ACC_PUBLIC | Opcodes.ACC_ABSTRACT, internalName, null,
            "java/lang/Object", null);
        if (marker != null) writer.visitAnnotation(marker, visible).visitEnd();
        if (methodMarker) {
            MethodVisitor method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_ABSTRACT,
                "annotatedMethod", "()V", null, null);
            method.visitAnnotation(MARKER, false).visitEnd();
            method.visitEnd();
        }
        writer.visitEnd();
        return writer.toByteArray();
    }

    private static void scan(byte[] bytes, ModFileScanData data) {
        ModClassVisitor scanner = new ModClassVisitor();
        new ClassReader(bytes).accept(scanner, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        scanner.buildData(data.getClasses(), data.getAnnotations());
    }

    private static void lazyStorageAndAttribution(Path origin) throws Exception {
        List<ModContainerImpl> providers = providers(origin, "fixture_primary", "fixture_secondary");
        ModContainerImpl primary = providers.get(0);
        ModContainerImpl secondary = providers.get(1);
        EntrypointStorage storage = new EntrypointStorage();
        CounterAdapter adapter = new CounterAdapter();
        storage.add(primary, "emi", metadata("existing.Plugin"), Map.of("test", () -> adapter));
        Map<String, ? extends java.util.Collection<Object>> before = storage.getModInstances();
        check(before.containsKey("fixture_primary") && !before.containsKey("fixture_secondary"),
            "Auxiliary view is populated before projection");
        NativeEmiEntrypoints.add(storage, secondary, "native.Plugin", adapter);
        Map<String, ? extends java.util.Collection<Object>> after = storage.getModInstances();
        check(after != before && after.keySet().containsAll(List.of("fixture_primary", "fixture_secondary")),
            "Projection refreshes an already cached auxiliary view and preserves existing provider");
        check(adapter.calls.get() == 0, "Registration does not instantiate plugin classes");
        List<EntrypointContainer<TestPlugin>> entries = storage.getEntrypointContainers("emi", TestPlugin.class);
        check(entries.size() == 2, "Existing entry is retained alongside projected entry");
        check(entries.get(0).getDefinition().equals("existing.Plugin"), "Existing order is retained");
        EntrypointContainer<TestPlugin> projected = entries.get(1);
        check(projected.getDefinition().equals("native.Plugin"), "Projected definition remains the class name");
        check(projected.getProvider() == secondary, "Provider is exact supplied host object, not first sibling");
        check(projected.getProvider().getMetadata().getId().equals("fixture_secondary"), "Provider ID is preserved");
        check(projected.getProvider().getOrigin().getPaths().equals(List.of(origin)), "Original provider origin is preserved");
        check(adapter.calls.get() == 0, "Container enumeration and provenance reads remain lazy");
        TestPlugin first = projected.getEntrypoint();
        check(adapter.calls.get() == 1, "First access constructs exactly once");
        check(storage.getModInstances().get("fixture_secondary").contains(first),
            "Refreshed auxiliary view sees the same lazy plugin instance");
        check(adapter.providers.equals(List.of(secondary)), "Adapter receives the exact host provider");
        check(adapter.definitions.equals(List.of("native.Plugin")), "Adapter receives original class definition");
        check(projected.getEntrypoint() == first, "Repeated access reuses the instance");
        check(storage.getEntrypointContainers("emi", TestPlugin.class).get(1).getEntrypoint() == first,
            "Fresh container wrappers reuse the store's instance");
        check(adapter.calls.get() == 1, "Repeated enumeration does not reconstruct");
        Object otherType = storage.getEntrypointContainers("emi", OtherPlugin.class).get(1).getEntrypoint();
        check(otherType != first && adapter.calls.get() == 2, "Standard store caches per requested type");
        check(storage.getEntrypointContainers("emi", OtherPlugin.class).get(1).getEntrypoint() == otherType,
            "Second requested type has its own stable cached instance");
        check(storage.getEntrypointContainers("other_key", TestPlugin.class).isEmpty(), "Projection affects only emi key");
    }

    private static void deferredFailureAttribution(Path origin) throws Exception {
        ModContainerImpl provider = providers(origin, "fixture_failure").get(0);
        EntrypointStorage storage = new EntrypointStorage();
        AtomicInteger attempts = new AtomicInteger();
        LanguageAdapter failing = new LanguageAdapter() {
            @Override public <T> T create(ModContainer mod, String definition, Class<T> type)
                    throws LanguageAdapterException {
                attempts.incrementAndGet();
                check(mod == provider, "Failing adapter retains provider identity");
                throw new LanguageAdapterException("fixture construction failed");
            }
        };
        NativeEmiEntrypoints.add(storage, provider, "fixture.FailingPlugin", failing);
        EntrypointContainer<TestPlugin> entry = storage.getEntrypointContainers("emi", TestPlugin.class).get(0);
        check(attempts.get() == 0, "Failure remains deferred until entrypoint access");
        try {
            entry.getEntrypoint();
            throw new AssertionError("Expected construction failure");
        } catch (EntrypointException failure) {
            check(failure.getMessage().contains("emi") && failure.getMessage().contains("fixture_failure"),
                "Construction error identifies the entrypoint key and provider");
            check(failure.getCause() instanceof LanguageAdapterException, "Original adapter failure is preserved");
        }
        check(attempts.get() == 1, "Single access invokes failing adapter once");
    }

    private static void nativeAdapterBehavior(Path origin) throws Exception {
        ModContainerImpl provider = providers(origin, "fixture_native_adapter").get(0);
        Module owner = NativeEmiEntrypointsTest.class.getModule();
        String fixturePrefix = NativeEmiEntrypointsTest.class.getName() + "$";
        String lazyName = fixturePrefix + "NativeLazyPlugin";
        LanguageAdapter adapter = NativeEmiEntrypoints.nativeAdapter(owner);
        check(nativeInitializations == 0 && nativeConstructions == 0,
            "Creating native adapter does not initialize or construct its fixture");

        // The same binary name exists in our module, but never in java.base.
        LanguageAdapter wrongOwner = NativeEmiEntrypoints.nativeAdapter(Object.class.getModule());
        expectNativeFailure(wrongOwner, provider, lazyName, IllegalStateException.class);
        check(nativeInitializations == 0 && nativeConstructions == 0,
            "Wrong module does not fall back to finding or initializing the fixture elsewhere");

        EntrypointStorage storage = new EntrypointStorage();
        NativeEmiEntrypoints.add(storage, provider, lazyName, adapter);
        EntrypointContainer<TestPlugin> entry = storage.getEntrypointContainers("emi", TestPlugin.class).get(0);
        check(entry.getProvider() == provider && entry.getDefinition().equals(lazyName),
            "Native adapter entry retains provider and binary class definition");
        check(nativeInitializations == 0 && nativeConstructions == 0,
            "Native entry registration and enumeration do not initialize or construct its fixture");
        TestPlugin instance = entry.getEntrypoint();
        check(instance.getClass().getModule() == owner && instance.getClass().getName().equals(lazyName),
            "Native adapter obtains the exact requested class in its selected module");
        check(nativeInitializations == 1 && nativeConstructions == 1,
            "First native entry access initializes and constructs exactly once");
        check(entry.getEntrypoint() == instance
                && storage.getEntrypointContainers("emi", TestPlugin.class).get(0).getEntrypoint() == instance,
            "Native adapter uses standard storage caching across repeated enumeration");
        check(nativeInitializations == 1 && nativeConstructions == 1,
            "Repeated native entry access does not initialize or reconstruct");

        expectNativeFailure(adapter, provider, fixturePrefix + "NativeWrongContract", IllegalStateException.class);
        check(wrongContractInitializations == 0 && wrongContractConstructions == 0,
            "Wrong contract is rejected before fixture initialization or construction");
        expectNativeFailure(adapter, provider, fixturePrefix + "MissingNativePlugin", IllegalStateException.class);
        expectNativeFailure(adapter, provider, fixturePrefix + "NativePrivateConstructor", NoSuchMethodException.class);
        check(privateConstructorInitializations == 0 && privateConstructorConstructions == 0,
            "Missing public constructor is rejected before initialization or construction");
    }

    private static void expectNativeFailure(LanguageAdapter adapter, ModContainerImpl provider, String definition,
                                           Class<? extends Throwable> causeType) {
        try {
            adapter.create(provider, definition, TestPlugin.class);
            throw new AssertionError("Expected native adapter rejection for " + definition);
        } catch (LanguageAdapterException failure) {
            check(failure.getMessage().contains(provider.getMetadata().getId())
                    && failure.getMessage().contains(definition),
                "Native adapter failure identifies provider and class: " + definition);
            check(causeType.isInstance(failure.getCause()),
                "Native adapter preserves rejection cause: " + definition);
        }
    }

    private static EntrypointMetadata metadata(String value) {
        return new EntrypointMetadata() {
            @Override public String getAdapter() { return "test"; }
            @Override public String getValue() { return value; }
        };
    }

    private static List<ModContainerImpl> providers(Path origin, String... ids) {
        IModInfo[] mods = new IModInfo[ids.length];
        IModFileInfo[] owner = new IModFileInfo[1];
        IModFile file = proxy(IModFile.class, (object, method, args) -> switch (method.getName()) {
            case "getFilePath" -> origin;
            case "getModFileInfo" -> owner[0];
            case "findResource" -> origin;
            default -> throw new AssertionError("Unexpected fixture file call: " + method);
        });
        owner[0] = proxy(IModFileInfo.class, (object, method, args) -> switch (method.getName()) {
            case "getFile" -> file;
            case "getMods" -> Arrays.asList(mods);
            default -> throw new AssertionError("Unexpected fixture owner call: " + method);
        });
        for (int i = 0; i < ids.length; i++) {
            String id = ids[i];
            mods[i] = proxy(IModInfo.class, (object, method, args) -> switch (method.getName()) {
                case "getOwningFile" -> owner[0];
                case "getModId", "getDisplayName" -> id;
                default -> throw new AssertionError("Unexpected fixture mod call: " + method);
            });
        }
        List<ModContainerImpl> result = new ArrayList<>();
        for (int i = 0; i < ids.length; i++) result.add(new ModContainerImpl(mods[i],
            new BuiltinMetadataWrapper(new BuiltinModMetadata.Builder(ids[i], "1.0.0").build())));
        return result;
    }

    private static <T> T proxy(Class<T> type, InvocationHandler handler) {
        return type.cast(Proxy.newProxyInstance(type.getClassLoader(), new Class<?>[] { type }, (object, method, args) -> {
            if (method.getDeclaringClass() == Object.class) return switch (method.getName()) {
                case "equals" -> object == args[0];
                case "hashCode" -> System.identityHashCode(object);
                case "toString" -> "Fixture<" + type.getSimpleName() + ">";
                default -> throw new AssertionError(method);
            };
            return handler.invoke(object, method, args);
        }));
    }

    private interface TestPlugin {}
    private interface OtherPlugin {}
    private static final class Plugin implements TestPlugin, OtherPlugin {}

    public static final class NativeLazyPlugin implements TestPlugin {
        static { nativeInitializations++; }
        public NativeLazyPlugin() { nativeConstructions++; }
    }

    public static final class NativeWrongContract {
        static { wrongContractInitializations++; }
        public NativeWrongContract() { wrongContractConstructions++; }
    }

    public static final class NativePrivateConstructor implements TestPlugin {
        static { privateConstructorInitializations++; }
        private NativePrivateConstructor() { privateConstructorConstructions++; }
    }

    private static final class CounterAdapter implements LanguageAdapter {
        final AtomicInteger calls = new AtomicInteger();
        final List<ModContainer> providers = new ArrayList<>();
        final List<String> definitions = new ArrayList<>();
        @Override public <T> T create(ModContainer mod, String definition, Class<T> type) {
            calls.incrementAndGet();
            providers.add(mod);
            definitions.add(definition);
            return type.cast(new Plugin());
        }
    }

    private static void check(boolean condition, String label) {
        checks++;
        if (!condition) throw new AssertionError(label);
    }
}
