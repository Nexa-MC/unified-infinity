#!/usr/bin/env python3
"""Seal the isolated EMI discovery candidate, never an accepted game result."""
import collections,datetime,difflib,hashlib,json,pathlib,shutil,sys,zipfile
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE/'assembly';SW=ROOT/'source-workspace';CORE=SW/'connector-four-loader'
PROJECT=HERE.parent.parent;BASE=PROJECT/'work/emi-plugin-discovery';CANON=BASE/'assembly'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value): (HERE/name).write_text(json.dumps(value,indent=2)+'\n')
old=json.loads((BASE/'build-identity.json').read_text())
identity=json.loads((CORE/'components/infinity-core/build/generated/resources/infinity/META-INF/unified-infinity/build-identity.json').read_text())
assert identity['dependencies']==old['dependencies']
def source(root,row):return root/'source-workspace'/row['path'].removeprefix('loader-sources/') if row['path'].startswith('loader-sources/') else root/'source-workspace/connector-four-loader'/row['path']
for row in old['sources']:assert sha(source(CANON,row))==row['sha256'],('canonical changed',row['path'])
for row in identity['sources']:assert sha(source(ROOT,row))==row['sha256'],('candidate changed',row['path'])
oldmap={r['path']:r for r in old['sources']};newmap={r['path']:r for r in identity['sources']}
changed=[n for n,r in newmap.items() if n not in oldmap or r['sha256']!=oldmap[n]['sha256']]
assert set(changed)=={'build.gradle.kts','src/main/java/org/sinytra/connector/client/EmiRenderRoute.java','src/main/java/org/sinytra/connector/service/ConnectorPreLaunchPlugin.java','src/main/java/org/sinytra/connector/service/EmiRenderMarker.java','src/main/java/org/sinytra/connector/service/EmiHostRenderScope.java','src/mod/java/org/sinytra/connector/mod/FmlGameCompatibilityComponent.java','src/mod/java/org/sinytra/connector/mod/compat/NativeEmiRenderBridge.java','four-loader/emi-render-tests/src/org/sinytra/connector/client/EmiRenderRouteTest.java','four-loader/emi-render-tests/src/org/sinytra/connector/service/EmiRenderMarkerTest.java','four-loader/emi-render-tests/src/org/sinytra/connector/service/EmiHostRenderScopeTest.java','four-loader/emi-render-tests/src/org/sinytra/connector/mod/compat/EmiPoseRestoreTest.java'},changed
assert oldmap.keys()<=newmap.keys()
patch=''
for n in sorted(changed):
 before=source(CANON,newmap[n]).read_text().splitlines(True) if n in oldmap else []
 after=source(ROOT,newmap[n]).read_text().splitlines(True)
 patch+=''.join(difflib.unified_diff(before,after,fromfile='a/'+n if before else '/dev/null',tofile='b/'+n))
(HERE/'emi-render-integration.patch').write_text(patch)
digest=hashlib.sha256()
for row in identity['sources']:digest.update(row['path'].encode()+b'\0'+source(ROOT,row).read_bytes()+b'\0')
lookup=collections.defaultdict(list)
for p in (SW/'gradle-cache/caches/modules-2/files-2.1').rglob('*.jar'):lookup[p.name].append(p)
for row in identity['dependencies']:
 p=next(p for p in lookup[row['filename']] if sha(p)==row['sha256'])
 digest.update(row['filename'].encode()+b'\0'+p.read_bytes()+b'\0')
digest.update(identity['compiler_runtime'].encode());assert digest.hexdigest()==identity['identity_sha256']
write('build-identity.json',identity)
write('source-identity-verification.json',{'status':'PASS_NEW_CANDIDATE_IDENTITY','identity':identity['identity_sha256'],'baselineIdentity':old['identity_sha256'],'sourceRecords':len(newmap),'unchangedDependencies':len(identity['dependencies']),'changedOrAddedSources':changed,'canonicalSourcesPreserved':len(oldmap),'sourceDigestReproduced':True,'gameAccepted':False})
version='2.0.0-beta.17+1.21.1+infinity-source+api1-emi-render-integration'
paths={'service':CORE/f'build/libs/connector-{version}-full.jar','game':CORE/f'build/libs/connector-{version}-mod.jar','fml':SW/'fml-unified/build/libs/fml-loader-4.0.42-unified-source.jar','product':ROOT/'runtime-bundle/build/libs/unified-infinity-0.1.0-dev.jar'}
write('built-core-artifacts.json',{role:{'path':str(p),'sha256':sha(p)} for role,p in paths.items() if role!='product'})
if '--core-only' in sys.argv:print(json.dumps({'phase':'CORE_IDENTIFIED','sourceIdentity':identity['identity_sha256'],'changed':changed}));raise SystemExit()
assert json.loads((HERE/'evidence/gradle-core-003.json').read_text())['status']=='PASS'
assert json.loads((HERE/'evidence/gradle-product-001.json').read_text())['status']=='PASS'
artifacts={};entries={};classes={};packages=collections.defaultdict(set)
for role,path in paths.items():
 dest=HERE/'artifacts'/f'{role}.jar';dest.parent.mkdir(exist_ok=True);shutil.copy2(path,dest)
 artifacts[role]={'path':str(dest),'sha256':sha(dest)}
 with zipfile.ZipFile(dest) as z:
  names=[n for n in z.namelist() if not n.endswith('/')];assert len(names)==len(set(names))
  entries[role]={n:hashlib.sha256(z.read(n)).hexdigest() for n in names}
  classes[role]={n for n in names if n.endswith('.class')}
  for n in classes[role]:packages[n.rsplit('/',1)[0]].add(role)
  if role=='service':assert json.loads(z.read('META-INF/unified-infinity/build-identity.json'))==identity
flat=[n for ns in classes.values() for n in ns];assert len(flat)==len(set(flat));assert all(len(v)==1 for v in packages.values())
assert 'org/sinytra/connector/locator/NativeEmiEntrypoints.class' in classes['service']
assert sum('net/fabricmc/loader/impl/FabricLoaderImpl.class' in ns for ns in classes.values())==1
prior=json.loads((BASE/'built-tuple-artifacts.json').read_text())
deltas={}
for role,row in prior.items():
 p=pathlib.Path(row['path']);assert sha(p)==row['sha256']
 with zipfile.ZipFile(p) as z:previous={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
 now=entries[role];deltas[role]={'priorSha256':row['sha256'],'newSha256':artifacts[role]['sha256'],'added':sorted(now.keys()-previous.keys()),'removed':sorted(previous.keys()-now.keys()),'changed':[n for n in sorted(now.keys()&previous.keys()) if now[n]!=previous[n]]}
write('artifact-delta.json',deltas)
write('built-tuple-artifacts.json',artifacts);write('artifact-entry-manifests.json',entries)
receipt=json.loads((BASE/'fml-base-build-receipt.json').read_text())
for n,h in receipt['sources'].items():assert sha(SW/n)==h
assert artifacts['fml']['sha256']==receipt['sha256']
receipt.update(artifact=artifacts['fml']['path'],sourceIdentitySha256=identity['identity_sha256'],buildKind='Isolated conditional EMI render-route successor; accepted plugin projection retained; unchanged FML bytes and dependency pins',sourceBuildReceipt=str(HERE/'evidence/gradle-core-003.json'))
write('fml-base-build-receipt.json',receipt)
archive=HERE/'candidate-complete-core-sources.zip';shutil.copy2(CORE/'build/distributions/unified-infinity-complete-connector-fart-adapter-sources.zip',archive)
with zipfile.ZipFile(archive) as z:
 for row in identity['sources']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'],row['path']
 assert 'LICENSE' in z.namelist()
seal={'schema':1,'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EMI_RENDER_SUCCESSOR_BUILT_CHECKED_GAME_UNVERIFIED','sourceIdentity':identity['identity_sha256'],'sources':len(newmap),'unchangedDependencies':len(identity['dependencies']),'artifacts':artifacts,'sourceArchive':{'path':str(archive),'sha256':sha(archive)},'duplicateClasses':0,'splitPackages':0,'fabricLoaderClassOwners':1,'classCounts':{k:len(v) for k,v in classes.items()},'canonicalSourcesPreserved':len(oldmap),'priorTuplePreserved':True,'fmlByteIdenticalToPrior':True,'patchSha256':sha(HERE/'emi-render-integration.patch'),'c1Integrated':False,'networkScaffoldIntegrated':False,'gameAccepted':False,'remainingRuntimeGates':['Fresh eight-real-mod combined client; actual BackpackScreen EMI grid/page/search visible','Ordinary vanilla container and EMI recipe browser show no duplicate rendering or input','Backpack crafting-upgrade Fill and full-process save/reopen remain passed; original JARs unchanged','Dedicated and separate-process networking remain independent future gates']}
write('candidate-seal.json',seal)
print(json.dumps(seal,indent=2))
