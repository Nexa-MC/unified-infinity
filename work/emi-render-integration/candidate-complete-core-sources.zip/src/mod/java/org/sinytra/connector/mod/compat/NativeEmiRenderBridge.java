// SPDX-License-Identifier: MIT
package org.sinytra.connector.mod.compat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.neoforged.fml.ModList;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.neoforge.client.event.ContainerScreenEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.sinytra.connector.ConnectorEarlyLoader;
import org.sinytra.connector.client.EmiRenderRoute;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Host render events fill only an actually skipped Fabric EMI container-render invocation. */
public final class NativeEmiRenderBridge {
    private static Module emiModule;
    private static Calls calls;
    private static boolean installed;
    private NativeEmiRenderBridge() {}

    public static synchronized void install() {
        if (installed) throw new IllegalStateException("Native EMI render bridge initialized twice");
        installed = true;
        if (!ConnectorEarlyLoader.isConnectorMod("emi")) return;
        var mod = ModList.get().getModContainerById("emi").orElseThrow().getModInfo();
        emiModule = FMLLoader.getGameLayer().findModule(mod.getOwningFile().moduleName()).orElseThrow();
        NeoForge.EVENT_BUS.addListener(NativeEmiRenderBridge::render);
        NeoForge.EVENT_BUS.addListener(NativeEmiRenderBridge::foreground);
    }

    /** Called by the host invocation wrapper, whose normal and exceptional exits close this scope. */
    public static void beginFrame(Object screen, Object context) {
        if (emiModule == null || !(screen instanceof AbstractContainerScreen<?>)) return;
        EmiRenderRoute.begin(screen, context, restoreOnFailure(((GuiGraphics) context).pose()));
    }

    static Runnable restoreOnFailure(PoseStack poses) {
        PoseStack.Pose baseline = poses.last();
        Matrix4f position = new Matrix4f(baseline.pose());
        Matrix3f normal = new Matrix3f(baseline.normal());
        return () -> {
            // The original Fabric hook pushes before invoking EMI, so an exception can skip its pop.
            while (poses.last() != baseline) {
                if (poses.clear()) throw new IllegalStateException("Container renderer popped below its entry pose");
                poses.popPose();
            }
            baseline.pose().set(position);
            baseline.normal().set(normal);
        };
    }

    private static void render(ContainerScreenEvent.Render.Foreground event) {
        var screen = event.getContainerScreen();
        GuiGraphics graphics = event.getGuiGraphics();
        if (!EmiRenderRoute.claimFallbackRender(screen, graphics)) return;
        graphics.pose().pushPose();
        try {
            // This native event runs while the pose is translated to the container origin.
            graphics.pose().translate(-screen.getGuiLeft(), -screen.getGuiTop(), 0);
            draw(false, graphics, event.getMouseX(), event.getMouseY());
        } finally { graphics.pose().popPose(); }
    }

    private static void foreground(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof AbstractContainerScreen<?>)) return;
        GuiGraphics graphics = event.getGuiGraphics();
        // Post is also emitted after a canceled Pre: a real fallback render is mandatory.
        if (!EmiRenderRoute.claimFallbackForeground(event.getScreen(), graphics)) return;
        graphics.pose().pushPose();
        try { draw(true, graphics, event.getMouseX(), event.getMouseY()); }
        finally { graphics.pose().popPose(); }
    }

    private static void draw(boolean foreground, GuiGraphics graphics, int mouseX, int mouseY) {
        Calls binding = calls();
        Object context = invoke(binding.wrap(), graphics);
        invoke(binding.shader());
        float delta = Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false);
        invoke(foreground ? binding.foreground() : binding.render(), context, mouseX, mouseY, delta);
    }

    private static synchronized Calls calls() {
        if (calls != null) return calls;
        try {
            Class<?> context = owned("dev.emi.emi.runtime.EmiDrawContext");
            Class<?> manager = owned("dev.emi.emi.screen.EmiScreenManager");
            Class<?> port = owned("dev.emi.emi.EmiPort");
            NativeEmiRenderBridge.class.getModule().addReads(emiModule);
            calls = new Calls(context.getMethod("wrap", GuiGraphics.class),
                manager.getMethod("render", context, int.class, int.class, float.class),
                manager.getMethod("drawForeground", context, int.class, int.class, float.class),
                port.getMethod("setPositionTexShader"));
            return calls;
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Selected Fabric EMI does not expose the pinned render contract", e);
        }
    }

    private static Class<?> owned(String name) {
        Class<?> type = Class.forName(emiModule, name);
        if (type == null || type.getModule() != emiModule) throw new IllegalStateException("EMI render class has another owner: " + name);
        return type;
    }

    private static Object invoke(Method method, Object... args) {
        try { return method.invoke(null, args); }
        catch (InvocationTargetException e) {
            if (e.getCause() instanceof RuntimeException failure) throw failure;
            if (e.getCause() instanceof Error failure) throw failure;
            throw new IllegalStateException("EMI rendering failed", e.getCause());
        } catch (ReflectiveOperationException e) { throw new IllegalStateException("Cannot invoke selected EMI renderer", e); }
    }

    private record Calls(Method wrap, Method render, Method foreground, Method shader) {}
}
