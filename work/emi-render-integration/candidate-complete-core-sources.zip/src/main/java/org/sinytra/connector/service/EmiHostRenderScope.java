// SPDX-License-Identifier: MIT
package org.sinytra.connector.service;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;

/** Adds a balanced invocation boundary to the one existing host screen-render owner. */
public final class EmiHostRenderScope {
    public static final String HOST = "net/neoforged/neoforge/client/ClientHooks";
    private static final String METHOD = "drawScreenInternal";
    private static final String RENAMED = "unified$emi$drawScreenInternal";
    private static final String DESC = "(Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/client/gui/GuiGraphics;IIF)V";
    private static final String ROUTE = "org/sinytra/connector/client/EmiRenderRoute";
    private static final String BRIDGE = "org/sinytra/connector/mod/compat/NativeEmiRenderBridge";
    private EmiHostRenderScope() {}

    public static boolean apply(ClassNode node) {
        if (!node.name.equals(HOST)) return false;
        if (node.methods.stream().anyMatch(m -> m.name.equals(RENAMED))) return false;
        var candidates = node.methods.stream().filter(m -> m.name.equals(METHOD) && m.desc.equals(DESC)).toList();
        if (candidates.size() != 1 || (candidates.getFirst().access & (Opcodes.ACC_STATIC | Opcodes.ACC_PRIVATE))
            != (Opcodes.ACC_STATIC | Opcodes.ACC_PRIVATE)) throw new IllegalStateException("Changed native screen render invocation contract");
        MethodNode original = candidates.getFirst();
        original.name = RENAMED;
        original.access |= Opcodes.ACC_SYNTHETIC;
        MethodNode wrapper = new MethodNode(Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC, METHOD, DESC, null, null);
        InsnList code = wrapper.instructions;
        objects(code);
        code.add(new MethodInsnNode(Opcodes.INVOKESTATIC, BRIDGE, "beginFrame", "(Ljava/lang/Object;Ljava/lang/Object;)V", false));
        LabelNode start = new LabelNode(), end = new LabelNode(), handler = new LabelNode();
        code.add(start);
        objects(code); code.add(new VarInsnNode(Opcodes.ILOAD, 2)); code.add(new VarInsnNode(Opcodes.ILOAD, 3)); code.add(new VarInsnNode(Opcodes.FLOAD, 4));
        code.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOST, RENAMED, DESC, false));
        code.add(end);
        objects(code); code.add(new MethodInsnNode(Opcodes.INVOKESTATIC, ROUTE, "end", "(Ljava/lang/Object;Ljava/lang/Object;)V", false));
        code.add(new InsnNode(Opcodes.RETURN));
        code.add(handler);
        code.add(new FrameNode(Opcodes.F_SAME1, 0, null, 1, new Object[] {"java/lang/Throwable"}));
        code.add(new VarInsnNode(Opcodes.ASTORE, 5));
        objects(code); code.add(new VarInsnNode(Opcodes.ALOAD, 5));
        code.add(new MethodInsnNode(Opcodes.INVOKESTATIC, ROUTE, "abort", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Throwable;)V", false));
        code.add(new VarInsnNode(Opcodes.ALOAD, 5)); code.add(new InsnNode(Opcodes.ATHROW));
        wrapper.tryCatchBlocks.add(new TryCatchBlockNode(start, end, handler, "java/lang/Throwable"));
        wrapper.maxLocals = 6; wrapper.maxStack = 5;
        node.methods.add(wrapper);
        return true;
    }

    private static void objects(InsnList code) { code.add(new VarInsnNode(Opcodes.ALOAD, 0)); code.add(new VarInsnNode(Opcodes.ALOAD, 1)); }
}
