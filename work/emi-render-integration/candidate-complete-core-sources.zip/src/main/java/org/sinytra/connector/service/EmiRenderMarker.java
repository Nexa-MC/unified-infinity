// SPDX-License-Identifier: MIT
package org.sinytra.connector.service;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;

/** Marks the existing Fabric EMI callback after Mixins have been applied; never draws anything. */
public final class EmiRenderMarker {
    private static final String SCREEN = "net/minecraft/client/gui/screens/inventory/AbstractContainerScreen";
    private static final String MANAGER = "dev/emi/emi/screen/EmiScreenManager";
    private static final String RENDER = "(Ldev/emi/emi/runtime/EmiDrawContext;IIF)V";
    private static final String CALLBACK = "(Lnet/minecraft/client/gui/GuiGraphics;IIFLorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V";
    private static final String ROUTE = "org/sinytra/connector/client/EmiRenderRoute";
    private EmiRenderMarker() {}

    public static boolean apply(ClassNode node) {
        if (!node.name.equals(SCREEN)) return false;
        MethodNode callback = null;
        MethodInsnNode render = null;
        int markers = 0, renders = 0;
        for (MethodNode method : node.methods) {
            for (AbstractInsnNode insn : method.instructions) {
                if (insn instanceof MethodInsnNode call) {
                    if (call.owner.equals(ROUTE) && call.name.equals("vanilla")) markers++;
                    if (call.owner.equals(MANAGER) && call.name.equals("render") && call.desc.equals(RENDER)) {
                        callback = method; render = call; renders++;
                    }
                }
            }
        }
        if (renders != 1 || callback == null || (callback.access & Opcodes.ACC_STATIC) != 0 || !callback.desc.equals(CALLBACK))
            throw new IllegalStateException("Expected one Fabric EMI container render callback, found " + renders);
        int foregrounds = 0;
        for (AbstractInsnNode insn : callback.instructions)
            if (insn instanceof MethodInsnNode call && call.owner.equals(MANAGER)
                && call.name.equals("drawForeground") && call.desc.equals(RENDER)) foregrounds++;
        if (foregrounds != 1) throw new IllegalStateException("Fabric EMI callback no longer owns its original foreground phase");
        if (markers == 1) return false;
        if (markers != 0) throw new IllegalStateException("Duplicate Fabric EMI render-route markers");
        InsnList marker = new InsnList();
        marker.add(new VarInsnNode(Opcodes.ALOAD, 0));
        marker.add(new VarInsnNode(Opcodes.ALOAD, 1));
        marker.add(new MethodInsnNode(Opcodes.INVOKESTATIC, ROUTE, "vanilla", "(Ljava/lang/Object;Ljava/lang/Object;)V", false));
        callback.instructions.insertBefore(render, marker);
        callback.maxStack += 2;
        return true;
    }
}
