// SPDX-License-Identifier: MIT
package org.sinytra.connector.locator;

import java.lang.annotation.ElementType;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.*;
import net.fabricmc.loader.api.LanguageAdapter;
import net.fabricmc.loader.api.LanguageAdapterException;
import net.fabricmc.loader.impl.FabricLoaderImpl;
import net.fabricmc.loader.impl.ModContainerImpl;
import net.fabricmc.loader.impl.entrypoint.EntrypointStorage;
import net.fabricmc.loader.impl.metadata.EntrypointMetadata;
import net.neoforged.neoforgespi.language.IModInfo;
import net.neoforged.neoforgespi.language.ModFileScanData;
import net.neoforged.neoforgespi.locating.IModFile;
import org.sinytra.connector.ConnectorEarlyLoader;
import org.sinytra.connector.util.ConnectorUtil;

/** Internal client projection into the existing loader store; owns no mod or plugin instances. */
public final class NativeEmiEntrypoints {
    private static final String ANNOTATION = "Ldev/emi/emi/api/EmiEntrypoint;";
    private static boolean installed;
    private NativeEmiEntrypoints() {}

    /** Called after the final host catalog freezes and before ordinary mod constructors run. */
    public static synchronized void install(List<? extends IModInfo> selected, ModuleLayer gameLayer, boolean client) {
        if (installed) throw new IllegalStateException("Native EMI entrypoints projected twice");
        installed = true;
        if (!client || !ConnectorEarlyLoader.isConnectorMod("emi")) return;
        var loader = FabricLoaderImpl.INSTANCE;
        if (!loader.hasEntrypoints("emi")) throw new IllegalStateException("Selected Fabric EMI has no entrypoint inventory");
        Set<IModFile> visited = Collections.newSetFromMap(new IdentityHashMap<>());
        List<Projection> pending = new ArrayList<>();
        Set<String> existing = new HashSet<>();
        for (var entry : loader.getEntrypointContainers("emi", Object.class))
            existing.add(entry.getProvider().getMetadata().getId() + "\0" + entry.getDefinition());

        for (IModInfo mod : selected) {
            IModFile file = mod.getOwningFile().getFile();
            if (!visited.add(file) || file.getModFileInfo().getFileProperties().containsKey(ConnectorUtil.CONNECTOR_MARKER)) continue;
            List<String> classes = annotatedClasses(file.getScanResult());
            if (classes.isEmpty()) continue;
            // A CLASS marker does not name a child mod. Never invent ownership for a multi-mod file.
            List<? extends IModInfo> owners = selected.stream().filter(m -> m.getOwningFile().getFile() == file).toList();
            if (owners.size() != 1) throw new IllegalStateException("Ambiguous native EMI plugin owner: " + file.getFilePath());
            var provider = loader.getModContainer(mod.getModId()).orElseThrow(() ->
                new IllegalStateException("Native EMI provider is hidden from the selected loader inventory: " + mod.getModId()));
            if (!(provider instanceof ModContainerImpl actual)
                || !provider.getOrigin().getPaths().equals(List.of(file.getFilePath())))
                throw new IllegalStateException("Native EMI provider origin differs from selected host owner: " + mod.getModId());
            Module owner = gameLayer.findModule(mod.getOwningFile().moduleName()).orElseThrow();
            for (String definition : classes) {
                if (existing.add(mod.getModId() + "\0" + definition)) pending.add(new Projection(actual, owner, definition));
            }
        }
        if (pending.isEmpty()) return;
        try {
            EntrypointStorage storage = (EntrypointStorage) Access.STORE.get(loader);
            for (Projection projection : pending)
                add(storage, projection.provider(), projection.definition(), nativeAdapter(projection.owner()));
        } catch (Exception e) {
            throw new IllegalStateException("Cannot project selected native EMI entrypoints", e);
        }
    }

    static List<String> annotatedClasses(ModFileScanData scan) {
        if (scan == null) throw new IllegalStateException("Selected mod has no completed host scan");
        return scan.getAnnotations().stream()
            .filter(a -> a.targetType() == ElementType.TYPE && a.annotationType().getDescriptor().equals(ANNOTATION))
            .map(a -> {
                if (!a.clazz().getClassName().equals(a.memberName())) throw new IllegalStateException("Invalid EMI TYPE annotation owner");
                return a.memberName();
            }).distinct().sorted().toList();
    }

    static void add(EntrypointStorage storage, ModContainerImpl provider, String definition, LanguageAdapter adapter) throws Exception {
        storage.add(provider, "emi", new EntrypointMetadata() {
            public String getAdapter() { return "default"; }
            public String getValue() { return definition; }
        }, Map.of("default", () -> adapter));
        // Upstream add() predates late host projections; keep its existing auxiliary view coherent.
        Access.INSTANCES.set(storage, null);
    }

    static LanguageAdapter nativeAdapter(Module owner) {
        return new LanguageAdapter() {
            @Override public <T> T create(net.fabricmc.loader.api.ModContainer provider, String value, Class<T> type) throws LanguageAdapterException {
                try {
                    // Module-scoped lookup neither initializes nor searches another provider's classes.
                    Class<?> implementation = Class.forName(owner, value);
                    if (implementation == null || implementation.getModule() != owner || !type.isAssignableFrom(implementation))
                        throw new IllegalStateException("Native EMI plugin does not implement the requested contract in its selected module: " + value);
                    NativeEmiEntrypoints.class.getModule().addReads(owner);
                    return type.cast(implementation.getConstructor().newInstance());
                } catch (ReflectiveOperationException | RuntimeException e) {
                    throw new LanguageAdapterException("Native EMI entrypoint " + value + " from " + provider.getMetadata().getId(), e);
                }
            }
        };
    }

    private record Projection(ModContainerImpl provider, Module owner, String definition) {}

    /** Pinned same-SERVICE-module implementation access, with no second store or public author API. */
    private static final class Access {
        private static final VarHandle STORE;
        private static final VarHandle INSTANCES;
        static {
            try {
                if (FabricLoaderImpl.class.getModule() != NativeEmiEntrypoints.class.getModule())
                    throw new IllegalStateException("Fabric loader store has another module owner");
                STORE = MethodHandles.privateLookupIn(FabricLoaderImpl.class, MethodHandles.lookup())
                    .findVarHandle(FabricLoaderImpl.class, "entrypointStorage", EntrypointStorage.class);
                INSTANCES = MethodHandles.privateLookupIn(EntrypointStorage.class, MethodHandles.lookup())
                    .findVarHandle(EntrypointStorage.class, "modInstances", Map.class);
            } catch (ReflectiveOperationException e) { throw new ExceptionInInitializerError(e); }
        }
    }
}
