/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Mod Compatibility Runtime contributors
 */
package org.sinytra.connector.client;

import java.util.Objects;

/**
 * Selects EMI's existing callback or the host fallback for one render invocation.
 *
 * <p>This service-layer class deliberately has no game types. The caller supplies
 * the current screen and graphics object as identity tokens. The host render
 * wrapper calls {@link #begin(Object, Object, Runnable)} before rendering, then
 * {@link #end} on normal return or {@link #abort} before rethrowing a failure.
 * Nested invocations receive independent frames, even when they reuse both
 * identity tokens.
 *
 * <p>The transplanted callback calls {@link #vanilla} immediately before its
 * original EMI render call. Host callbacks claim their work before invoking EMI;
 * a failed callback must not be retried within the same invocation. A canceled
 * Pre never reaches a container callback and only needs its matching end call.
 */
public final class EmiRenderRoute {
    private static final ThreadLocal<Frame> CURRENT = new ThreadLocal<>();

    private EmiRenderRoute() {}

    /** Opens one invocation, preserving any reentrant parent invocation. */
    public static void begin(Object screen, Object graphics) {
        begin(screen, graphics, null);
    }

    /**
     * Opens an invocation with optional failure-only cleanup. The cleanup may
     * restore graphics state captured by the game adapter; normal end never
     * invokes it. A null cleanup is equivalent to the two-argument overload.
     */
    public static void begin(Object screen, Object graphics, Runnable failureCleanup) {
        Objects.requireNonNull(screen, "screen");
        Objects.requireNonNull(graphics, "graphics");
        CURRENT.set(new Frame(screen, graphics, CURRENT.get(), failureCleanup));
    }

    /**
     * Gives the existing transplanted callback ownership of the current frame.
     * A marker for another screen or graphics context, or outside a host render,
     * changes nothing.
     */
    public static void vanilla(Object screen, Object graphics) {
        Frame frame = current(screen, graphics);
        if (frame != null) {
            frame.vanilla = true;
        }
    }

    /** Claims one fallback render only when the original callback did not run. */
    public static boolean claimFallbackRender(Object screen, Object graphics) {
        Frame frame = current(screen, graphics);
        if (frame == null || frame.vanilla || frame.fallbackRender) {
            return false;
        }
        frame.fallbackRender = true;
        return true;
    }

    /**
     * Claims one fallback foreground after this invocation claimed fallback
     * render. Foreground events alone cannot select the fallback route.
     */
    public static boolean claimFallbackForeground(Object screen, Object graphics) {
        Frame frame = current(screen, graphics);
        if (frame == null || frame.vanilla || !frame.fallbackRender || frame.fallbackForeground) {
            return false;
        }
        frame.fallbackForeground = true;
        return true;
    }

    /**
     * Closes the matching current invocation and restores its parent. An end for
     * another screen or graphics object cannot close a nested invocation.
     */
    public static void end(Object screen, Object graphics) {
        Frame frame = current(screen, graphics);
        if (frame == null) {
            return;
        }
        restoreParent(frame);
    }

    /**
     * Restores a failed invocation's captured state, then closes that frame.
     * Cleanup is claimed before execution and cannot run twice for the frame.
     * Its failure is suppressed onto the non-null primary failure, which the
     * caller must rethrow. A mismatched current identity pair is a no-op.
     */
    public static void abort(Object screen, Object graphics, Throwable primary) {
        Frame frame = current(screen, graphics);
        if (frame == null) {
            return;
        }
        try {
            Objects.requireNonNull(primary, "primary");
            if (!frame.cleanupAttempted) {
                frame.cleanupAttempted = true;
                try {
                    if (frame.failureCleanup != null) {
                        frame.failureCleanup.run();
                    }
                } catch (Throwable cleanupFailure) {
                    if (cleanupFailure != primary) {
                        primary.addSuppressed(cleanupFailure);
                    }
                }
            }
        } finally {
            restoreParent(frame);
        }
    }

    private static void restoreParent(Frame frame) {
        if (frame.parent == null) {
            CURRENT.remove();
        } else {
            CURRENT.set(frame.parent);
        }
    }

    private static Frame current(Object screen, Object graphics) {
        Frame frame = CURRENT.get();
        return frame != null && frame.screen == screen && frame.graphics == graphics ? frame : null;
    }

    private static final class Frame {
        private final Object screen;
        private final Object graphics;
        private final Frame parent;
        private final Runnable failureCleanup;
        private boolean vanilla;
        private boolean fallbackRender;
        private boolean fallbackForeground;
        private boolean cleanupAttempted;

        private Frame(Object screen, Object graphics, Frame parent, Runnable failureCleanup) {
            this.screen = screen;
            this.graphics = graphics;
            this.parent = parent;
            this.failureCleanup = failureCleanup;
        }
    }
}
