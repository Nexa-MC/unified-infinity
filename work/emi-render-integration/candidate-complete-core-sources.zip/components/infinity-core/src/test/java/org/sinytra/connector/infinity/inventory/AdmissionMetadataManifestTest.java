package org.sinytra.connector.infinity.inventory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import javax.tools.ToolProvider;
import static org.sinytra.connector.infinity.inventory.AdmissionInventory.*;

/** Admission inspects bounded main attributes while the JDK retains JAR signature handling. */
public final class AdmissionMetadataManifestTest {
    private static final int LIMIT = 1024 * 1024;
    private static final String MANIFEST = "META-INF/MANIFEST.MF";
    private static final String SERVICE = "cpw.mods.modlauncher.api.ITransformationService";
    private static int assertions;
    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("admission-manifest-");
        try {
            byte[] module = module(directory);
            for (String newline : List.of("\n", "\r\n", "\r")) {
                String main = "Manifest-Version: 1.0" + newline + "Multi-Release: tr" + newline + " ue" + newline + newline;
                Map<String, byte[]> entries = new HashMap<>();
                entries.put(MANIFEST, bytes(main + "Name: ignored" + newline + "X-Digest: " + "x".repeat(2 * LIMIT)));
                entries.put("META-INF/versions/9/module-info.class", module);
                check(scan(directory, entries).candidate().earlyServiceProvider(), "Folded multi-release main attributes select provider module: " + newline.length());
                entries.put(MANIFEST, bytes("Manifest-Version: 1.0" + newline + newline + "Name: ignored" + newline + "Multi-Release: true" + newline));
                check(!scan(directory, entries).candidate().earlyServiceProvider(), "Named-section Multi-Release cannot enable module provider");
                // A resource stream must never be read beyond the main-section delimiter.
                byte[] prefix = bytes(main.substring(0, main.length() - (newline.equals("\r\n") ? 1 : 0)));
                var resources = new AdmissionMetadata.Resources() {
                    public boolean has(String name) { return name.equals(MANIFEST); }
                    public InputStream open(String name) {
                        return new InputStream() {
                            int offset;
                            public int read() {
                                if (offset == prefix.length) throw new AssertionError("Read named manifest section");
                                return prefix[offset++] & 255;
                            }
                        };
                    }
                };
                check(!AdmissionMetadata.scan(directory, new SourceChain("stream", List.of()), resources).candidate().earlyServiceProvider(), "Stops at first empty line");
            }
            Map<String, byte[]> entries = new HashMap<>();
            entries.put(MANIFEST, bytes("Manifest-Version: 1.0\n\n" + "Name: digest\nSHA-256-Digest: abc\n\n".repeat(70000)));
            entries.put("META-INF/services/" + SERVICE, bytes("fixture.Provider\n"));
            check(scan(directory, entries).candidate().earlyServiceProvider(), "Large named sections preserve service-file flag");
            entries.remove("META-INF/services/" + SERVICE);
            entries.put("module-info.class", module);
            check(scan(directory, entries).candidate().earlyServiceProvider(), "Large named sections preserve base-module service flag");
            entries.clear(); entries.put(MANIFEST, mainAtSize(LIMIT));
            check(!scan(directory, entries).candidate().earlyServiceProvider(), "Main attributes exactly at previous ceiling accepted");
            entries.put(MANIFEST, mainAtSize(LIMIT + 1));
            rejects(directory, entries, "Oversized manifest main attributes", "Oversized main section rejected");
            entries.put(MANIFEST, bytes("Manifest-Version: 1.0\n broken-before-header\n\n"));
            entries.put("module-info.class", module);
            check(scan(directory, entries).candidate().earlyServiceProvider(), "Legal continuation retains module service flag");
            entries.clear(); entries.put(MANIFEST, bytes("broken header\n\n"));
            rejects(directory, entries, "invalid header", "Malformed main section rejected");
            for (String descriptor : List.of("fabric.mod.json", "quilt.mod.json", "META-INF/mods.toml", "META-INF/neoforge.mods.toml", "META-INF/jarjar/metadata.json", "module-info.class")) {
                entries.clear(); entries.put(MANIFEST, bytes("Manifest-Version: 1.0\n\n"));
                entries.put(descriptor, bytes(" ".repeat(LIMIT + 1)));
                rejects(directory, entries, "oversized descriptor", "Original bound retained: " + descriptor);
            }
            if (args.length == 2) {
                Path platform = Path.of(args[0]);
                check(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(platform))).equals(args[1]), "Official platform hash verified");
                check(!AdmissionMetadata.scan(platform, new SourceChain(platform.toString(), List.of())).candidate().earlyServiceProvider(), "Original signed server-extra manifest accepted without rewriting");
            } else if (args.length != 0) throw new IllegalArgumentException("Expected optional official JAR path and SHA256");
            System.out.println("PASS " + assertions + " manifest-main admission assertions");
        } finally {
            try (var paths = Files.walk(directory)) { for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path); }
        }
    }
    private static byte[] mainAtSize(int size) {
        StringBuilder main = new StringBuilder("Manifest-Version: 1.0\nX-Large: value\n");
        while (main.length() + 73 < size) main.append(' ').append("x".repeat(70)).append('\n');
        int remaining = size - main.length() - 1;
        if (remaining > 0) main.append(' ').append("x".repeat(remaining - 2)).append('\n');
        return bytes(main.append('\n').toString());
    }
    private static byte[] module(Path directory) throws Exception {
        Path src = directory.resolve("module-src"), output = directory.resolve("module-out");
        Path service = src.resolve("cpw/mods/modlauncher/api/ITransformationService.java"), provider = src.resolve("fixture/Provider.java"), descriptor = src.resolve("module-info.java");
        Files.createDirectories(service.getParent()); Files.createDirectories(provider.getParent());
        Files.writeString(service, "package cpw.mods.modlauncher.api; public interface ITransformationService {}");
        Files.writeString(provider, "package fixture; public class Provider implements " + SERVICE + " {}");
        Files.writeString(descriptor, "module fixture { provides " + SERVICE + " with fixture.Provider; }");
        check(ToolProvider.getSystemJavaCompiler().run(null, null, null, "-proc:none", "--release", "21", "-d", output.toString(), service.toString(), provider.toString(), descriptor.toString()) == 0, "Compile module-provider fixture");
        return Files.readAllBytes(output.resolve("module-info.class"));
    }
    private static AdmissionMetadata.Scan scan(Path directory, Map<String, byte[]> entries) throws Exception {
        Path file = directory.resolve("fixture.jar");
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(file))) {
            for (var entry : entries.entrySet()) { output.putNextEntry(new ZipEntry(entry.getKey())); output.write(entry.getValue()); output.closeEntry(); }
        }
        return AdmissionMetadata.scan(file, new SourceChain(file.toString(), List.of()));
    }
    private static void rejects(Path directory, Map<String, byte[]> entries, String message, String label) throws Exception {
        try { scan(directory, entries); throw new AssertionError(label); }
        catch (IOException expected) { check(expected.getMessage().toLowerCase(Locale.ROOT).contains(message.toLowerCase(Locale.ROOT)), label + ": " + expected); }
    }
    private static byte[] bytes(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static void check(boolean condition, String label) { assertions++; if (!condition) throw new AssertionError(label); }
}
