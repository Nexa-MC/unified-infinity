package org.sinytra.connector.infinity.inventory;

import java.nio.file.Path;
import java.util.*;
import static org.sinytra.connector.infinity.inventory.AdmissionInventory.*;
import static org.sinytra.connector.infinity.inventory.InfrastructurePolicy.*;

/** A third managed QSL identity affects presence notices and grouping, never dependency satisfaction. */
public final class QuiltTooltipInventoryTest {
    private static int checks;
    static int run() {
        var source = new SourceChain("/external/tooltip.jar", List.of());
        var decision = evaluate(new Candidate(Path.of(source.installationRoot()), source, Ecosystem.QUILT, List.of("quilt_tooltip"), false));
        check(decision.action() == Action.EXCLUDE, "external tooltip must not start a second API owner");
        check(decision.exclusions().getFirst().ruleId().equals("qsl-tooltip"), "dedicated tooltip rule");
        check(reconcileNotices(decision.exclusions(), Set.of("quilt_base", "quilt_lifecycle_events")).getFirst().replacement() == Replacement.NOT_VERIFIED, "baseline profile cannot advertise tooltip presence");
        var selected = reconcileNotices(decision.exclusions(), Set.of("quilt_base", "quilt_lifecycle_events", "quilt_tooltip")).getFirst();
        check(selected.replacement() == Replacement.SELECTED_PROVIDER_PRESENT && selected.selectedReplacementIds().equals(List.of("quilt_tooltip")), "only exact selected tooltip provider is reported");
        var absent = evaluate(new Candidate(Path.of("/external/dimension.jar"), source, Ecosystem.QUILT, List.of("quilt_dimension"), false));
        check(reconcileNotices(absent.exclusions(), Set.of("quilt_tooltip")).getFirst().replacement() == Replacement.NO_API_REPLACEMENT, "tooltip does not claim other QSL APIs");
        check(evaluate(new Candidate(Path.of("/external/mixed.jar"), source, Ecosystem.QUILT, List.of("quilt_tooltip", "valuable_content"), false)).action() == Action.BLOCK_MIXED_FILE, "mixed archive content is not silently hidden");
        check(AuditedInfrastructureIds.UNSUPPORTED_QSL.size() == 27 && !AuditedInfrastructureIds.UNSUPPORTED_QSL.contains("quilt_tooltip"), "only tooltip leaves unsupported module set");
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < 44; i++) entries.add(api("ffapi_fixture_" + i, Ecosystem.NEOFORGE, Lane.NATIVE_HOST));
        for (String id : List.of("quilt_base", "quilt_lifecycle_events", "quilt_tooltip")) entries.add(api(id, Ecosystem.QUILT, Lane.NATIVE_QUILT));
        var snapshot = new Snapshot(1, "tooltip-candidate", entries, Counts.of(entries), List.of());
        var display = InventoryDisplay.project(snapshot);
        check(display.counts().loadedLogicalMods() == 47 && display.counts().collapsedApiModules() == 47 && display.counts().apiSummaryRows() == 1, "44 FFAPI plus three QSL logical modules group once");
        check(display.apiCredits().stream().filter(e -> e.canonicalId().equals("quilt_tooltip")).count() == 1, "one actual tooltip identity retained in credits");
        Entry tooltip = display.apiCredits().getLast();
        check(tooltip.sourceVersion().orElseThrow().equals("10.0.0-alpha.5+1.21.1") && tooltip.licenses().equals(List.of("Apache-2.0")), "raw version and original license retained");
        return checks;
    }
    private static Entry api(String id, Ecosystem ecosystem, Lane lane) {
        return new Entry(id, Optional.of(id), id, Optional.of("10.0.0-alpha.5+1.21.1"), Optional.of("10.0.0-alpha.5+1.21.1"), "10.0.0-alpha.5+1.21.1", ecosystem, lane, Category.BUNDLED_API, Optional.empty(), List.of("Apache-2.0"), new Provenance(List.of(new SourceChain("/installed/product.jar", List.of("META-INF/jarjar/" + id + ".jar"))), "/runtime/" + id + ".jar", Optional.empty(), Evidence.MANAGED_PINNED_EXTRACTION));
    }
    private static void check(boolean value, String message) { checks++; if (!value) throw new AssertionError(message); }
}
