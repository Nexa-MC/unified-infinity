#!/usr/bin/env bash
# Compare frozen pre-change symbol rules and current admission using one unchanged own probe.
# Does not launch Gradle or Minecraft. Compile the probe separately with its pinned build.py.
set -euo pipefail
cd "$(dirname "$0")/../.."
java_bin="${JAVA_HOME:-../../.toolchains/jdk-21.0.12.1+1}/bin"
libs="${FORGE_FACADE_HOST_LIBRARIES:-../../run/neoforge-native/libraries}"
out=build/forge-api-probe-tests
mkdir -p "$out/current" "$out/baseline"
asm=$(find "$libs/org/ow2/asm" -type f -path '*/9.8/*.jar' -print | sort | paste -sd:)
classpath=$(find "$libs" -type f -name '*.jar' -print | sort | paste -sd:)
classpath="$asm:$classpath"
src=components/infinity-forge/src
identity=components/infinity-core/build/generated/sources/infinity/java/org/sinytra/connector/infinity/BuildIdentity.java
baseline=../../docs/api-coverage/forge/baseline-source/source-workspace/connector-four-loader/components/infinity-forge/src/main/java/org/sinytra/connector/forge/transform/Forge52Symbols.java
probe=../../four-loader/forge-api-probe/build/unified-forge-api-probe-0.1.0.jar
"$java_bin/javac" --release 21 -proc:none -cp "$classpath" -d "$out/current" "$identity" \
  "$src/main/java/org/sinytra/connector/forge/transform/Forge52Symbols.java" \
  "$src/main/java/org/sinytra/connector/forge/discovery/Forge52Metadata.java" \
  "$src/main/java/org/sinytra/connector/forge/discovery/Forge52Resources.java" \
  "$src/main/java/org/sinytra/connector/forge/discovery/Forge52JarAdapter.java" \
  "$src/test/java/org/sinytra/connector/forge/discovery/ForgeApiProbeTransformTest.java"
"$java_bin/javac" --release 21 -proc:none -cp "$classpath" -d "$out/baseline" "$baseline"
"$java_bin/java" -ea -cp "$out/baseline:$out/current:$classpath" \
  org.sinytra.connector.forge.discovery.ForgeApiProbeTransformTest "$probe" baseline
"$java_bin/java" -ea -cp "$out/current:$classpath" \
  org.sinytra.connector.forge.discovery.ForgeApiProbeTransformTest "$probe"
