package org.sinytra.connector.forge.runtime;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

/** Contract tests over a controllable host holder; never initializes a game registry. */
public final class ForgeRegistryLazyMapTest {
    private static int checks;

    public static void main(String[] args) {
        var registry = ResourceKey.<String>createRegistryKey(ResourceLocation.fromNamespaceAndPath("test", "absent_registry"));
        var key = ResourceKey.create(registry, ResourceLocation.fromNamespaceAndPath("lazy_map_test", "entry"));
        var holder = new ControlledHolder(key);
        var object = new RegistryObject<>(holder);
        AtomicInteger mappings = new AtomicInteger();
        Function<CharSequence, StringBuilder> mapper = value -> {
            mappings.incrementAndGet();
            return new StringBuilder(value);
        };
        // Contravariant input and covariant output are part of the source API.
        Supplier<CharSequence> lazy = object.lazyMap(mapper);
        check(mappings.get() == 0 && holder.getCalls == 0 && holder.presenceCalls == 0,
            "supplier creation neither reads holder nor calls mapper");
        check(lazy.get() == null && lazy.get() == null, "absent supplier repeatedly returns null");
        check(mappings.get() == 0 && holder.getCalls == 0, "absent access does not call mapper or getter");
        expectNullMapper(object);

        holder.value = "first";
        CharSequence first = lazy.get();
        CharSequence second = lazy.get();
        check(first.toString().equals("first") && second.toString().equals("first"), "prebound supplier sees registration later");
        check(first != second && mappings.get() == 2 && holder.getCalls == 2, "every access maps again without memoization");
        holder.value = "replacement";
        check(lazy.get().toString().equals("replacement"), "supplier re-reads current registered value");
        expectNullMapper(object);

        AtomicInteger nullMappings = new AtomicInteger();
        Supplier<Object> mappedNull = object.lazyMap(value -> { nullMappings.incrementAndGet(); return null; });
        check(mappedNull.get() == null && mappedNull.get() == null && nullMappings.get() == 2,
            "null result is valid and is not cached");
        var mapperFailure = new IllegalStateException("own-lazy-mapper-failure");
        Supplier<Object> throwing = object.lazyMap(value -> { throw mapperFailure; });
        check(capture(throwing) == mapperFailure && capture(throwing) == mapperFailure,
            "mapper exception propagates unchanged on every access");
        var mapperError = new AssertionError("own-lazy-mapper-error");
        check(capture(object.lazyMap(value -> { throw mapperError; })) == mapperError, "mapper Error propagates unchanged");

        int previousMappings = mappings.get();
        int previousReads = holder.getCalls;
        holder.value = null;
        check(lazy.get() == null && throwing.get() == null, "later absence skips even a throwing mapper");
        check(mappings.get() == previousMappings && holder.getCalls == previousReads, "absence is checked anew before reading");
        holder.value = "rebound";
        check(lazy.get().toString().equals("rebound"), "supplier remains usable after another binding");
        var getterFailure = new IllegalStateException("own-host-getter-failure");
        holder.failure = getterFailure;
        int beforeFailure = mappings.get();
        check(capture(lazy) == getterFailure && mappings.get() == beforeFailure,
            "bound getter failure propagates before mapper runs");
        System.out.println("PASS: " + checks + " Forge lazyMap contract checks (controlled host holder, no game launch)");
    }

    private static void expectNullMapper(RegistryObject<String> object) {
        try { object.lazyMap(null); throw new AssertionError("null mapper accepted"); }
        catch (NullPointerException expected) { check(true, "null mapper is rejected immediately, regardless of presence"); }
    }

    private static Throwable capture(Supplier<?> supplier) {
        try { supplier.get(); }
        catch (Throwable failure) { return failure; }
        throw new AssertionError("expected supplier failure");
    }

    private static void check(boolean value, String label) { if (!value) throw new AssertionError(label); checks++; }

    private static final class ControlledHolder extends DeferredHolder<String, String> {
        String value;
        RuntimeException failure;
        int getCalls;
        int presenceCalls;
        ControlledHolder(ResourceKey<String> key) { super(key); }
        @Override protected Registry<String> getRegistry() { return null; }
        @Override public boolean isBound() { presenceCalls++; return value != null; }
        @Override public String get() { getCalls++; if (failure != null) throw failure; return value; }
    }
}
