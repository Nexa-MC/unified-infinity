package org.sinytra.connector.forge.discovery;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.TreeSet;
import java.util.zip.ZipFile;
import org.sinytra.connector.forge.transform.Forge52Symbols;

/** The same original own probe must fail slice 2 and adapt under slice 3. */
public final class ForgeApiProbeTransformTest {
    private static final String ORIGINAL = "71985bf644262c6c411332f741e25d95b64d5f51800a27c697f4d928470b22c3";
    private static int checks;

    public static void main(String[] args) throws Exception {
        Path probe = Path.of(args[0]);
        boolean rejection = args.length > 1 && args[1].equals("baseline");
        check(Forge52JarAdapter.sha256(probe).equals(ORIGINAL), "frozen original probe identity");
        try (ZipFile jar = new ZipFile(probe.toFile())) {
            byte[] main = jar.getInputStream(jar.getEntry("dev/infinity/forgeapiprobe/ForgeApiProbe.class")).readAllBytes();
            if (rejection) {
                check(Forge52Symbols.rules().startsWith("forge52-mojmap-slice-2-clumps-events\n"), "genuine frozen pre-change ABI");
                try { Forge52Symbols.transform(main, new TreeSet<>()); throw new AssertionError("baseline accepted new contract"); }
                catch (IllegalArgumentException expected) {
                    check(expected.getMessage().contains("Unsupported Forge 52.1.0 ABI slice: method net/minecraftforge/registries/RegistryObject.lazyMap(Ljava/util/function/Function;)Ljava/util/function/Supplier;"), "baseline rejects precise unsupported lazyMap descriptor");
                    System.out.println("PASS: unchanged API probe is rejected before change: " + expected.getMessage());
                }
                return;
            }
        }
        Path cache = Files.createTempDirectory("forge-api-contract-cache-");
        var adapted = Forge52JarAdapter.adapt(probe, cache, "SERVER");
        check(!adapted.cacheHit(), "cold candidate adapts new probe");
        var warm = Forge52JarAdapter.adapt(probe, cache, "SERVER");
        check(warm.cacheHit() && warm.outputSha256().equals(adapted.outputSha256()), "new probe cache reuse verifies output");
        try (ZipFile original = new ZipFile(probe.toFile()); ZipFile derived = new ZipFile(adapted.output().toFile())) {
            check(Arrays.equals(original.getInputStream(original.getEntry(Forge52JarAdapter.SOURCE_TOML)).readAllBytes(),
                derived.getInputStream(derived.getEntry(Forge52JarAdapter.SOURCE_TOML)).readAllBytes()), "original Forge descriptor retained exactly");
            String audit = new String(derived.getInputStream(derived.getEntry(Forge52JarAdapter.AUDIT_RESOURCE)).readAllBytes(), StandardCharsets.UTF_8);
            check(audit.contains(ORIGINAL) && audit.contains("forge52-mojmap-slice-3-lazy-registry-supplier-work"), "audit pins input and new ABI");
            check(audit.contains("RegistryObject.lazyMap(Ljava/util/function/Function;)Ljava/util/function/Supplier;"), "lazyMap invocation and descriptor audited");
            check(audit.contains("FMLCommonSetupEvent.enqueueWork(Ljava/util/function/Supplier;)Ljava/util/concurrent/CompletableFuture;"), "supplier queue invocation and descriptor audited");
            int classes = 0;
            var entries = derived.entries();
            while (entries.hasMoreElements()) {
                var entry = entries.nextElement();
                if (!entry.getName().endsWith(".class")) continue;
                classes++;
                check(!new String(derived.getInputStream(entry).readAllBytes(), StandardCharsets.ISO_8859_1).contains("net/minecraftforge/"), "no runtime Forge implementation symbol: " + entry.getName());
            }
            check(classes == 2, "both own probe classes transformed");
        }
        check(Forge52JarAdapter.sha256(probe).equals(ORIGINAL), "original probe never rewritten");
        System.out.println("PASS: " + checks + " unchanged Forge API probe transform/cache checks; original=" + ORIGINAL);
    }

    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); checks++; }
}
