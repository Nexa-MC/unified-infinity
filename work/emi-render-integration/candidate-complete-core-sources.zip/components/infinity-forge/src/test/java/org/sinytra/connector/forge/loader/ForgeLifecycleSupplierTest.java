package org.sinytra.connector.forge.loader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import net.neoforged.fml.DeferredWorkQueue;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

/** Exercises the actual host event/queue, including failures that cannot be in a successful game launch. */
final class ForgeLifecycleSupplierTest {
    private static int checks;

    static void run(ModContainer container) throws InterruptedException {
        var queue = new DeferredWorkQueue("Forge supplier contract");
        var event = new FMLCommonSetupEvent(container, queue);
        var order = new ArrayList<String>();
        var executionThread = new AtomicReference<Thread>();
        var expected = new Object();
        CompletableFuture<Void> before = event.enqueueWork((Runnable) () -> {
            executionThread.set(Thread.currentThread());
            owner(container);
            order.add("runnable");
        });
        CompletableFuture<Object> result = event.enqueueWork(() -> {
            owner(container);
            check(Thread.currentThread() == executionThread.get(), "supplier shares queue's runnable thread");
            order.add("supplier");
            return expected;
        });
        CompletableFuture<Object> nullResult = event.enqueueWork(() -> {
            owner(container);
            order.add("null");
            return null;
        });
        try { event.enqueueWork((Supplier<Object>) null); throw new AssertionError("null supplier accepted"); }
        catch (NullPointerException expectedFailure) { check(true, "null supplier rejected at enqueue time"); }
        check(order.isEmpty() && !before.isDone() && !result.isDone() && !nullResult.isDone(), "all work/futures stay deferred before drain");
        var drain = drain(queue);
        check(drain.failure == null, "successful queue drain has no aggregate failure");
        check(executionThread.get() == drain.thread, "queue uses its draining thread");
        check(order.equals(List.of("runnable", "supplier", "null")), "same-owner runnable and suppliers preserve FIFO order");
        check(before.join() == null && result.join() == expected && nullResult.join() == null, "future preserves result identity and null");
        check(order.size() == 3, "future observation does not re-execute work");
        check(drain.contextCleared, "successful queue clears owner context");

        var failureQueue = new DeferredWorkQueue("Forge expected supplier failures");
        var failureEvent = new FMLCommonSetupEvent(container, failureQueue);
        var failure = new IllegalStateException("expected-owned-supplier-failure");
        var error = new AssertionError("expected-owned-supplier-error");
        var failedOrder = new ArrayList<String>();
        CompletableFuture<Object> failed = failureEvent.enqueueWork((Supplier<Object>) () -> {
            owner(container); failedOrder.add("failure"); throw failure;
        });
        CompletableFuture<Object> errored = failureEvent.enqueueWork((Supplier<Object>) () -> {
            owner(container); failedOrder.add("error"); throw error;
        });
        CompletableFuture<Integer> after = failureEvent.enqueueWork(() -> {
            owner(container); failedOrder.add("after"); return 42;
        });
        check(!failed.isDone() && !errored.isDone() && !after.isDone(), "throwing suppliers also stay deferred");
        var failedDrain = drain(failureQueue);
        check(failedDrain.failure instanceof RuntimeException, "queue propagates an aggregate loading failure");
        check(Arrays.equals(failedDrain.failure.getSuppressed(), new Throwable[]{failure, error}), "queue aggregate keeps original failure identities and order");
        check(futureFailure(failed) == failure && futureFailure(errored) == error, "exceptional futures keep original exception/Error causes");
        check(after.join() == 42 && failedOrder.equals(List.of("failure", "error", "after")), "queue continues in order after individual failures");
        check(failedDrain.contextCleared, "failed queue clears owner context");
        System.out.println("PASS: " + checks + " Forge lifecycle Supplier contract checks (actual host queue; expected failures logged)");
    }

    private static void owner(ModContainer container) {
        check(ModLoadingContext.get().getActiveContainer() == container, "queued work receives owning native container");
    }

    private static Throwable futureFailure(CompletableFuture<?> future) {
        try { future.join(); throw new AssertionError("exceptional future succeeded"); }
        catch (CompletionException expected) { return expected.getCause(); }
    }

    private static Drain drain(DeferredWorkQueue queue) throws InterruptedException {
        var failure = new AtomicReference<Throwable>();
        var cleared = new AtomicReference<Boolean>(false);
        var thread = new Thread(() -> {
            try { queue.runTasks(); }
            catch (Throwable thrown) { failure.set(thrown); }
            finally { cleared.set(ModLoadingContext.get().getActiveNamespace().equals("minecraft")); }
        }, "forge-contract-main-queue");
        thread.start();
        thread.join(10_000);
        check(!thread.isAlive(), "bounded queue drain completed");
        return new Drain(thread, failure.get(), cleared.get());
    }

    private record Drain(Thread thread, Throwable failure, boolean contextCleared) {}
    private static void check(boolean value, String label) { if (!value) throw new AssertionError(label); checks++; }
}
